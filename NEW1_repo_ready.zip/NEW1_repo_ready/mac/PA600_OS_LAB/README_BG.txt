PA600 OS LAB v0.2 — iMac 2011 / macOS 10.13

НАЙ-ЛЕСНО:
1. Разархивирай ZIP файла.
2. Двоен клик върху PA600_OS_LAB.html.
3. Той трябва да се отвори директно в Safari/Chrome.

Алтернатива:
- Run_PA600_OS_LAB.command

Тази версия НЕ използва Python, Tkinter, Homebrew или допълнителни библиотеки.

KorgPackage:
- Каченият от теб KorgPackage v1.2 е Java 8 JAR.
- В папката има Run_KorgPackage.command.
- За него трябва да има Java 8 на Mac-а.

OS LAB v0.2:
- 800x480 PA600 тестов интерфейс
- HOME / STYLE / SOUND / MEDIA / FX PORT / DIAGNOSTICS / PKG TEST
- виртуален eMMC и USB слой
- никакъв запис към истински PA600
- локално избиране на .PKG за тест

Ако macOS блокира .command:
десен бутон -> Open.
Но PA600_OS_LAB.html трябва да се отвори и без .command.
