#!/bin/bash
BASE="$(cd "$(dirname "$0")" && pwd)"
if /usr/bin/java -version >/dev/null 2>&1; then
  exec /usr/bin/java -jar "$BASE/KorgPackage.jar"
else
  echo
  echo "Java 8 не е намерена."
  echo "KorgPackage v1.2 е Java 8 приложение и изисква JRE/JDK 8."
  echo
  read -p "Натисни Enter за затваряне..."
fi
