#!/bin/bash
BASE="$(cd "$(dirname "$0")" && pwd)"
open "$BASE/PA600_OS_LAB.html"
