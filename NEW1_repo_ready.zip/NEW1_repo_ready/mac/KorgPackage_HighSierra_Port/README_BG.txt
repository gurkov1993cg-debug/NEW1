KorgPackage High Sierra Port v1.0
For iMac 2011 / macOS 10.13 High Sierra

THIS BUILD DOES NOT USE JAVA OR JAVAFX.

Start:
1. Unzip.
2. Right-click `KorgPackage High Sierra.app` -> Open.
3. It opens its local interface in Chrome/Safari.
4. Fallback: double-click `START_KorgPackage.command`.

Why the interface opens in the browser:
The package parser/writer is ported from the GPL KorgPackage source to a local Python 2.7 engine.
macOS 10.13 already includes /usr/bin/python. The browser is used only as the UI; all PKG
processing happens locally on 127.0.0.1. Nothing is uploaded to the Internet.

Implemented:
- Open KORG .PKG
- package MD5 verification
- display chunks
- System files: kernel/ramdisk/service/MLO/U-Boot
- File chunks: RAW/ZLIB/encrypted payload preservation
- RootFS
- Installer scripts
- Directory chunks
- Export selected
- Export all ZIP
- Replace binary data
- Add file
- edit metadata
- remove chunk from working copy
- Save modified .PKG as a NEW download
- internal engine self-test

Safety:
The opened original PKG is copied to a temporary work area. The program never overwrites
the original file. Unknown chunk payloads are preserved byte-for-byte.

Logs if it does not launch:
Desktop/KorgPackage_HighSierra_launch.log
Desktop/KorgPackage_HS_error.log

License:
This port is based on the GPL-3.0 KorgPackage project by Polprzewodnikowy.
Port source is included in /source and distributed under GPL-3.0.
