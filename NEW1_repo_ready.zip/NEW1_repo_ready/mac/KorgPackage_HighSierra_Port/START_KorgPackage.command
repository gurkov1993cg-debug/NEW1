#!/bin/bash
BASE="$(cd "$(dirname "$0")" && pwd)"
open "$BASE/KorgPackage High Sierra.app"
sleep 2
if ! /usr/bin/curl -fsS "http://127.0.0.1:48600/api/state" >/dev/null 2>&1 ; then
  echo "App did not start through LaunchServices. Starting engine directly..."
  "$BASE/KorgPackage High Sierra.app/Contents/MacOS/KorgPackageHighSierra"
fi
