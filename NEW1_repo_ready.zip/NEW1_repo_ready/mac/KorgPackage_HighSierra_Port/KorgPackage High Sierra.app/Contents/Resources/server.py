# -*- coding: utf-8 -*-
from __future__ import print_function
import os, sys, json, tempfile, shutil, zipfile, threading, time, cgi, mimetypes, traceback
try:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urlparse import urlparse, parse_qs
except ImportError:
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, parse_qs

BASE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,BASE)
from engine import *

PORT=48600
WORK=tempfile.mkdtemp(prefix="KorgPackageHS_Server_")
PKG=Package()
CURRENT_NAME=""

def jdump(o):
    return json.dumps(o,ensure_ascii=False).encode("utf-8")

def clean_name(s):
    s=os.path.basename(s or "file.bin")
    return s.replace("\x00","")

def state():
    return {
      "loaded": bool(PKG.chunks),
      "name": CURRENT_NAME,
      "hash_ok": PKG.hash_ok,
      "expected_md5": PKG.expected_md5.hex() if hasattr(PKG.expected_md5,"hex") else "".join("%02x"%ord(x) for x in PKG.expected_md5),
      "calculated_md5": PKG.calculated_md5.hex() if hasattr(PKG.calculated_md5,"hex") else "".join("%02x"%ord(x) for x in PKG.calculated_md5),
      "chunks": PKG.summary()
    }

class H(BaseHTTPRequestHandler):
    server_version="KorgPackageHS/1.0"
    def log_message(self,fmt,*args):
        try:
            with open(os.path.expanduser("~/Desktop/KorgPackage_HS.log"),"a") as f:
                f.write(("%s - "+fmt+"\n")%(self.address_string(),)+args)
        except Exception: pass

    def send_bytes(self,data,ctype="application/octet-stream",name=None,code=200):
        self.send_response(code); self.send_header("Content-Type",ctype)
        self.send_header("Content-Length",str(len(data)))
        if name: self.send_header("Content-Disposition",'attachment; filename="%s"'%clean_name(name))
        self.end_headers(); self.wfile.write(data)

    def send_json(self,o,code=200):
        self.send_bytes(jdump(o),"application/json; charset=utf-8",code=code)

    def send_file(self,path,name=None,ctype="application/octet-stream"):
        st=os.stat(path)
        self.send_response(200); self.send_header("Content-Type",ctype)
        self.send_header("Content-Length",str(st.st_size))
        if name: self.send_header("Content-Disposition",'attachment; filename="%s"'%clean_name(name))
        self.end_headers()
        with open(path,"rb") as f:
            while True:
                b=f.read(1024*1024)
                if not b: break
                self.wfile.write(b)

    def do_GET(self):
        u=urlparse(self.path)
        if u.path=="/":
            return self.send_file(os.path.join(BASE,"index.html"),ctype="text/html; charset=utf-8")
        if u.path=="/api/state": return self.send_json(state())
        if u.path.startswith("/api/chunk/"):
            try:
                idx=int(u.path.split("/")[-1]); return self.send_json(PKG.chunks[idx].info())
            except Exception as e: return self.send_json({"error":str(e)},400)
        if u.path.startswith("/download/chunk/"):
            try:
                idx=int(u.path.split("/")[-1]); c=PKG.chunks[idx]
                d=tempfile.mkdtemp(dir=WORK)
                out=c.export_to(d)
                if out and os.path.isfile(out): return self.send_file(out,os.path.basename(out))
                return self.send_json({"error":"Chunk has no exportable file"},400)
            except Exception as e: return self.send_json({"error":str(e)},400)
        if u.path=="/download/all":
            if not PKG.chunks: return self.send_json({"error":"No package loaded"},400)
            d=tempfile.mkdtemp(dir=WORK); exp=os.path.join(d,"export")
            PKG.export_all(exp)
            zp=os.path.join(d,"KorgPackage_export.zip")
            with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as z:
                for root,ds,fs in os.walk(exp):
                    for fn in fs:
                        p=os.path.join(root,fn); z.write(p,os.path.relpath(p,exp))
            return self.send_file(zp,"KorgPackage_export.zip","application/zip")
        if u.path=="/download/save":
            if not PKG.chunks: return self.send_json({"error":"No package loaded"},400)
            out=os.path.join(WORK,"PA600_modified.pkg"); PKG.save(out)
            return self.send_file(out,"PA600_modified.pkg")
        if u.path=="/api/selftest":
            p=os.path.join(WORK,"selftest.pkg")
            ok=make_test_package(p)
            return self.send_json({"ok":ok})
        if u.path=="/api/quit":
            self.send_json({"ok":True})
            threading.Thread(target=self.server.shutdown).start()
            return
        return self.send_bytes(b"Not found","text/plain",code=404)

    def parse_form(self):
        ctype,pdict=cgi.parse_header(self.headers.get("content-type",""))
        if ctype=="multipart/form-data":
            pdict["boundary"]=pdict["boundary"].encode("ascii")
            fs=cgi.FieldStorage(fp=self.rfile,headers=self.headers,environ={"REQUEST_METHOD":"POST","CONTENT_TYPE":self.headers.get("content-type")})
            return fs
        l=int(self.headers.get("content-length","0") or 0)
        body=self.rfile.read(l)
        return body

    def do_POST(self):
        global CURRENT_NAME
        try:
            if self.path=="/api/open":
                fs=self.parse_form()
                item=fs["file"]
                name=clean_name(item.filename)
                p=os.path.join(WORK,"opened.pkg")
                with open(p,"wb") as o: shutil.copyfileobj(item.file,o)
                PKG.load(p); CURRENT_NAME=name
                return self.send_json(state())
            if self.path=="/api/replace":
                fs=self.parse_form(); idx=int(fs["idx"].value); item=fs["file"]
                c=PKG.chunks[idx]
                if not isinstance(c,DataChunk): return self.send_json({"error":"Selected chunk has no replaceable binary data"},400)
                p=os.path.join(WORK,"replacement.bin")
                with open(p,"wb") as o: shutil.copyfileobj(item.file,o)
                c.replace_data(p); return self.send_json({"ok":True,"chunk":c.info()})
            if self.path=="/api/addfile":
                fs=self.parse_form(); target=fs["target"].value; item=fs["file"]
                if not PKG.temp_dir: return self.send_json({"error":"Open a package first"},400)
                c=FileChunk(); c.name=target; c.make_temp(PKG.temp_dir)
                with open(c.data_path,"wb") as o: shutil.copyfileobj(item.file,o)
                PKG.chunks.append(c); return self.send_json(state())
            l=int(self.headers.get("content-length","0") or 0); body=self.rfile.read(l)
            data=json.loads(body.decode("utf-8") if hasattr(body,"decode") else body)
            if self.path=="/api/remove":
                idx=int(data["idx"])
                if PKG.chunks[idx].id==HEADER: return self.send_json({"error":"Header is protected"},400)
                del PKG.chunks[idx]; return self.send_json(state())
            if self.path=="/api/meta":
                idx=int(data["idx"]); vals=data.get("values",{}); c=PKG.chunks[idx]
                def intval(k,old):
                    if k not in vals: return old
                    s=str(vals[k]).strip()
                    try: return int(s,0)
                    except Exception: return int(s)
                if isinstance(c,HeaderChunk):
                    c.pkg_type=intval("pkg_type",c.pkg_type)
                    c.system_type=vals.get("system_type",c.system_type)
                    c.build_system1=vals.get("build_system1",c.build_system1); c.build_system2=vals.get("build_system2",c.build_system2)
                    c.date=vals.get("date",c.date); c.time=vals.get("time",c.time)
                    c.package_type1=vals.get("package_type1",c.package_type1); c.package_type2=vals.get("package_type2",c.package_type2)
                elif isinstance(c,DirectoryChunk):
                    c.owner=intval("owner",c.owner); c.group=intval("group",c.group); c.attributes=intval("attributes",c.attributes)
                    c.condition=intval("condition",c.condition); c.path=vals.get("path",c.path)
                elif isinstance(c,FileChunk):
                    c.owner=intval("owner",c.owner); c.group=intval("group",c.group); c.attributes=intval("attributes",c.attributes)
                    c.condition=intval("condition",c.condition); c.compression_type=intval("compression",c.compression_type)
                    c.name=vals.get("name",c.name); c.date=vals.get("date",c.date); c.time=vals.get("time",c.time)
                elif isinstance(c,InstallerScriptChunk):
                    c.condition=intval("condition",c.condition); c.name=vals.get("name",c.name)
                elif isinstance(c,RootFSChunk):
                    c.condition=intval("condition",c.condition); c.path=vals.get("path",c.path)
                return self.send_json({"ok":True,"chunk":c.info()})
            return self.send_json({"error":"Unknown endpoint"},404)
        except Exception as e:
            try:
                with open(os.path.expanduser("~/Desktop/KorgPackage_HS_error.log"),"a") as f:
                    f.write(traceback.format_exc()+"\n")
            except Exception: pass
            return self.send_json({"error":str(e)},500)

def main():
    import subprocess
    httpd=HTTPServer(("127.0.0.1",PORT),H)
    url="http://127.0.0.1:%d/"%PORT
    try: subprocess.Popen(["/usr/bin/open",url])
    except Exception: pass
    try: httpd.serve_forever()
    finally:
        try: PKG.close()
        except Exception: pass
        try: shutil.rmtree(WORK)
        except Exception: pass

if __name__=="__main__":
    main()
