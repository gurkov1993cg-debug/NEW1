# -*- coding: utf-8 -*-
from __future__ import print_function
import os, struct, hashlib, zlib, tempfile, shutil, time

HEADER=1
UPDATE_KERNEL=2
UPDATE_RAMDISK=3
UPDATE_INSTALLER_APP=4
UPDATE_INSTALLER_APP_CONFIG=5
SERVICE_KERNEL=6
SERVICE_RAMDISK=7
SERVICE_APP=8
SERVICE_APP_CONFIG=9
UPDATE_LAUNCHER_APP=10
UPDATE_LAUNCHER_APP_CONFIG=11
MLO=12
UBOOT=13
USER_KERNEL=14
INSTALLER_SCRIPT=15
DIRECTORY=16
FILE=17
LINK=18
ROOT_FS=19

COMPRESSION_RAW=0
COMPRESSION_ZLIB=1
ENCRYPTED=16

SYSTEM_PATHS={
2:("update","uImage"),3:("update","ramdisk.gz"),
4:("update","lfo-pkg-install"),5:("update","lfo-pkg-install.xml"),
6:("service","uImage"),7:("service","ramdisk.gz"),
8:("service","lfo-service"),9:("service","lfo-service.xml"),
10:("service","lfo-pkg-launcher"),11:("service","lfo-pkg-launcher.xml"),
12:("boot","MLO"),13:("boot","u-boot.bin"),14:("kernel","uImage")
}
TYPE_NAMES={
1:"Header",2:"Update kernel",3:"Update ramdisk",4:"Update installer",
5:"Update installer config",6:"Service kernel",7:"Service ramdisk",
8:"Service app",9:"Service app config",10:"Update launcher",
11:"Update launcher config",12:"MLO",13:"U-Boot",14:"User kernel",
15:"Installer script",16:"Directory",17:"File",18:"Link/unknown",19:"RootFS"
}

def bstr(s):
    if isinstance(s, bytes): return s
    return s.encode("latin-1","replace")

def ustr(b):
    if isinstance(b, str):
        try: return b.decode("latin-1")
        except AttributeError: return b
    return b.decode("latin-1","replace")

def r_u32le(f):
    b=f.read(4)
    if len(b)!=4: raise EOFError("Unexpected EOF")
    return struct.unpack("<I",b)[0]
def r_u16le(f):
    b=f.read(2)
    if len(b)!=2: raise EOFError("Unexpected EOF")
    return struct.unpack("<H",b)[0]
def r_s16le(f):
    v=r_u16le(f)
    return v-65536 if v>=32768 else v
def r_u32be(f):
    b=f.read(4)
    if len(b)!=4: raise EOFError("Unexpected EOF")
    return struct.unpack(">I",b)[0]
def w_u32le(f,v): f.write(struct.pack("<I",int(v)&0xffffffff))
def w_u16le(f,v): f.write(struct.pack("<H",int(v)&0xffff))
def w_u32be(f,v): f.write(struct.pack(">I",int(v)&0xffffffff))

def r_zstr(f):
    a=[]
    while True:
        c=f.read(1)
        if not c: raise EOFError("EOF reading string")
        if c==b"\x00": break
        a.append(c)
    return ustr(b"".join(a))
def w_zstr(f,s):
    f.write(bstr(s)); f.write(b"\x00")

def copy_n(src,dst,n,buf=1024*1024):
    left=int(n)
    while left>0:
        x=src.read(min(left,buf))
        if not x: raise EOFError("Truncated data")
        dst.write(x); left-=len(x)

def md5_path(p):
    h=hashlib.md5()
    with open(p,"rb") as f:
        while True:
            b=f.read(1024*1024)
            if not b: break
            h.update(b)
    return h.digest()

class Chunk(object):
    def __init__(self,cid):
        self.id=cid
        self.source_size=0
        self.data_path=None
        self.temp_dir=None
    def type_name(self): return TYPE_NAMES.get(self.id,"Unknown")
    def display_path(self): return ""
    def data_size(self):
        return os.path.getsize(self.data_path) if self.data_path and os.path.exists(self.data_path) else 0
    def info(self):
        return {"id":self.id,"type":self.type_name(),"path":self.display_path(),"size":self.data_size()}
    def export_to(self,base):
        if self.data_path:
            if not os.path.isdir(base): os.makedirs(base)
            out=os.path.join(base,"chunk_%d.bin"%self.id)
            shutil.copy2(self.data_path,out); return out
        return None
    def write_chunk(self,out):
        w_u32le(out,self.id)
        szpos=out.tell(); w_u32le(out,0)
        start=out.tell(); self.write_payload(out); end=out.tell()
        out.seek(szpos); w_u32le(out,end-start); out.seek(end)

class DataChunk(Chunk):
    def make_temp(self,temp_dir,suffix=".bin"):
        self.temp_dir=temp_dir
        fd,p=tempfile.mkstemp(prefix="kp_%02d_"%self.id,suffix=suffix,dir=temp_dir)
        os.close(fd); self.data_path=p; return p
    def replace_data(self,src):
        if not self.data_path: raise ValueError("Chunk has no binary data")
        shutil.copy2(src,self.data_path)

class HeaderChunk(Chunk):
    def __init__(self):
        Chunk.__init__(self,HEADER)
        self.pkg_lib_version=[3,6,4,3]; self.pkg_type=2
        self.unknown=[2,1]; self.system_type="103ASTD"
        self.build_system1="KORG-SW1"; self.build_system2="WorkHorse2"
        self.date="01/01/2014"; self.time="12:00"
        self.package_type1="Z103A package"; self.package_type2=" user package"
    def load_payload(self,f,size,tmp):
        self.pkg_lib_version=list(bytearray(f.read(4)))
        self.pkg_type=r_u32le(f); self.unknown=[r_s16le(f),r_s16le(f)]
        self.system_type=r_zstr(f); self.build_system1=r_zstr(f); self.build_system2=r_zstr(f)
        self.date=r_zstr(f); self.time=r_zstr(f); self.package_type1=r_zstr(f); self.package_type2=r_zstr(f)
    def write_payload(self,out):
        out.write(bytes(bytearray(self.pkg_lib_version)))
        w_u32le(out,self.pkg_type); w_u16le(out,self.unknown[0]); w_u16le(out,self.unknown[1])
        for s in [self.system_type,self.build_system1,self.build_system2,self.date,self.time,self.package_type1,self.package_type2]:
            w_zstr(out,s)
    def display_path(self): return self.system_type
    def info(self):
        d=Chunk.info(self)
        d.update({"pkg_lib_version":".".join(str(x) for x in self.pkg_lib_version),
                  "pkg_type":self.pkg_type,"unknown1":self.unknown[0],"unknown2":self.unknown[1],
                  "system_type":self.system_type,"build_system1":self.build_system1,
                  "build_system2":self.build_system2,"date":self.date,"time":self.time,
                  "package_type1":self.package_type1,"package_type2":self.package_type2})
        return d
    def export_to(self,base):
        if not os.path.isdir(base): os.makedirs(base)
        out=os.path.join(base,"Header.txt")
        lines=["PkgLib version: "+ ".".join(str(x) for x in self.pkg_lib_version),
               "Package type: "+str(self.pkg_type),
               "[%s, %s]"%(self.unknown[0],self.unknown[1]),self.system_type,self.build_system1,
               self.build_system2,self.date,self.time,self.package_type1,self.package_type2]
        with open(out,"wb") as f: f.write(bstr("\r\n".join(lines)+"\r\n"))
        return out

class SystemFileChunk(DataChunk):
    def __init__(self,cid): DataChunk.__init__(self,cid)
    def load_payload(self,f,size,tmp):
        if size<16: raise ValueError("System chunk too small")
        f.read(16)
        p=self.make_temp(tmp)
        with open(p,"wb") as o: copy_n(f,o,size-16)
    def write_payload(self,out):
        out.write(md5_path(self.data_path))
        with open(self.data_path,"rb") as f:
            while True:
                b=f.read(1024*1024)
                if not b: break
                out.write(b)
    def display_path(self):
        a,b=SYSTEM_PATHS.get(self.id,("unknown","unknown"))
        return "/"+a+"/"+b
    def export_to(self,base):
        a,b=SYSTEM_PATHS.get(self.id,("unknown","unknown"))
        d=os.path.join(base,a)
        if not os.path.isdir(d): os.makedirs(d)
        out=os.path.join(d,b); shutil.copy2(self.data_path,out); return out

class InstallerScriptChunk(DataChunk):
    def __init__(self):
        DataChunk.__init__(self,INSTALLER_SCRIPT); self.condition=-1; self.name="script.sh"
    def load_payload(self,f,size,tmp):
        start=f.tell()
        if size<19: raise ValueError("Installer script chunk too small")
        f.read(16); self.condition=r_s16le(f); self.name=r_zstr(f)
        used=f.tell()-start
        p=self.make_temp(tmp,".sh")
        with open(p,"wb") as o: copy_n(f,o,size-used)
    def write_payload(self,out):
        out.write(md5_path(self.data_path)); w_u16le(out,self.condition); w_zstr(out,self.name)
        with open(self.data_path,"rb") as f:
            while True:
                b=f.read(1024*1024)
                if not b: break
                out.write(b)
    def display_path(self): return "/update/"+self.name
    def info(self):
        d=DataChunk.info(self); d.update({"condition":self.condition,"name":self.name}); return d
    def export_to(self,base):
        d=os.path.join(base,"update")
        if not os.path.isdir(d): os.makedirs(d)
        out=os.path.join(d,self.name); shutil.copy2(self.data_path,out); return out

class DirectoryChunk(Chunk):
    def __init__(self):
        Chunk.__init__(self,DIRECTORY)
        self.owner=0; self.group=0; self.attributes=0x7000; self.condition=-1; self.path="/omega_sys/directory"
    def load_payload(self,f,size,tmp):
        self.owner=r_s16le(f); self.group=r_s16le(f); self.attributes=r_u16le(f); self.condition=r_s16le(f); self.path=r_zstr(f)
    def write_payload(self,out):
        w_u16le(out,self.owner); w_u16le(out,self.group); w_u16le(out,self.attributes); w_u16le(out,self.condition); w_zstr(out,self.path)
    def display_path(self): return self.path
    def info(self):
        d=Chunk.info(self); d.update({"owner":self.owner,"group":self.group,
        "attributes":"0x%04X"%(self.attributes&0xffff),"condition":self.condition,"path":self.path}); return d
    def export_to(self,base):
        p=self.path[1:] if self.path.startswith("/") else self.path
        out=os.path.join(base,p)
        if not os.path.isdir(out): os.makedirs(out)
        return out

class FileChunk(DataChunk):
    def __init__(self):
        DataChunk.__init__(self,FILE)
        self.owner=0; self.group=0; self.attributes=0x7000; self.condition=-1
        self.compression_type=COMPRESSION_ZLIB; self.name="/omega_sys/file"
        self.date="01/01/2016"; self.time="12:00"; self.declared_data_size=0
    def load_payload(self,f,size,tmp):
        start=f.tell()
        if size<29: raise ValueError("File chunk too small")
        f.read(16); self.owner=r_s16le(f); self.group=r_s16le(f)
        self.attributes=r_u16le(f); self.condition=r_s16le(f)
        self.declared_data_size=r_u32le(f)
        c=f.read(1)
        if not c: raise EOFError("EOF compression type")
        self.compression_type=struct.unpack("B",c)[0]
        self.name=r_zstr(f); self.date=r_zstr(f); self.time=r_zstr(f)
        p=self.make_temp(tmp)
        with open(p,"wb") as o:
            if self.compression_type==COMPRESSION_RAW:
                copy_n(f,o,self.declared_data_size)
            elif self.compression_type==ENCRYPTED:
                used=f.tell()-start
                copy_n(f,o,max(0,size-used))
            elif self.compression_type==COMPRESSION_ZLIB:
                while True:
                    marker=r_u32le(f)
                    if marker!=0x100:
                        if marker==0x101:
                            _=r_u32le(f)
                        break
                    comp_size=r_u32le(f)-4
                    uncomp_size=r_u32be(f)
                    comp=f.read(comp_size)
                    if len(comp)!=comp_size: raise EOFError("Truncated zlib block")
                    data=zlib.decompress(comp)
                    if len(data)!=uncomp_size: raise ValueError("Bad zlib block size")
                    o.write(data)
                    rem=comp_size%4
                    if rem: f.read(4-rem)
            else:
                used=f.tell()-start
                copy_n(f,o,max(0,size-used))
    def write_payload(self,out):
        out.write(md5_path(self.data_path))
        w_u16le(out,self.owner); w_u16le(out,self.group); w_u16le(out,self.attributes); w_u16le(out,self.condition)
        w_u32le(out,self.data_size())
        out.write(struct.pack("B",self.compression_type&0xff))
        w_zstr(out,self.name); w_zstr(out,self.date); w_zstr(out,self.time)
        if self.compression_type in (COMPRESSION_RAW,ENCRYPTED):
            with open(self.data_path,"rb") as f:
                while True:
                    b=f.read(1024*1024)
                    if not b: break
                    out.write(b)
        elif self.compression_type==COMPRESSION_ZLIB:
            with open(self.data_path,"rb") as f:
                while True:
                    raw=f.read(0x100000)
                    if not raw: break
                    comp=zlib.compress(raw,9)
                    w_u32le(out,0x100); w_u32le(out,len(comp)+4); w_u32be(out,len(raw)); out.write(comp)
                    rem=len(comp)%4
                    if rem: out.write(b"\x00"*(4-rem))
            w_u32le(out,0x101); w_u32le(out,0)
        else:
            with open(self.data_path,"rb") as f:
                while True:
                    b=f.read(1024*1024)
                    if not b: break
                    out.write(b)
    def display_path(self): return self.name
    def info(self):
        d=DataChunk.info(self)
        d.update({"owner":self.owner,"group":self.group,"attributes":"0x%04X"%(self.attributes&0xffff),
                  "condition":self.condition,"compression":self.compression_type,
                  "name":self.name,"date":self.date,"time":self.time,
                  "declared_data_size":self.declared_data_size})
        return d
    def export_to(self,base):
        p=self.name[1:] if self.name.startswith("/") else self.name
        out=os.path.join(base,p); d=os.path.dirname(out)
        if d and not os.path.isdir(d): os.makedirs(d)
        shutil.copy2(self.data_path,out); return out

class RootFSChunk(DataChunk):
    def __init__(self):
        DataChunk.__init__(self,ROOT_FS); self.condition=-1; self.path="/rootfs/user-release.tar"; self.declared_data_size=0
    def load_payload(self,f,size,tmp):
        if size<23: raise ValueError("RootFS chunk too small")
        f.read(16); self.declared_data_size=r_u32le(f); self.condition=r_s16le(f); self.path=r_zstr(f)
        p=self.make_temp(tmp,".tar")
        with open(p,"wb") as o: copy_n(f,o,self.declared_data_size)
    def write_payload(self,out):
        out.write(md5_path(self.data_path)); w_u32le(out,self.data_size()); w_u16le(out,self.condition); w_zstr(out,self.path)
        with open(self.data_path,"rb") as f:
            while True:
                b=f.read(1024*1024)
                if not b: break
                out.write(b)
    def display_path(self): return self.path
    def info(self):
        d=DataChunk.info(self); d.update({"condition":self.condition,"path":self.path,
        "declared_data_size":self.declared_data_size}); return d
    def export_to(self,base):
        p=self.path[1:] if self.path.startswith("/") else self.path
        out=os.path.join(base,p); d=os.path.dirname(out)
        if d and not os.path.isdir(d): os.makedirs(d)
        shutil.copy2(self.data_path,out); return out

class RawChunk(DataChunk):
    # Safer than the old Java UnknownChunk saver: preserve unknown payload byte-for-byte.
    def __init__(self,cid):
        DataChunk.__init__(self,cid)
    def load_payload(self,f,size,tmp):
        p=self.make_temp(tmp)
        with open(p,"wb") as o: copy_n(f,o,size)
    def write_payload(self,out):
        with open(self.data_path,"rb") as f:
            while True:
                b=f.read(1024*1024)
                if not b: break
                out.write(b)
    def display_path(self): return "Unknown chunk 0x%X"%self.id

class Package(object):
    def __init__(self):
        self.path=None; self.chunks=[]; self.temp_dir=None
        self.expected_md5=b""; self.calculated_md5=b""; self.hash_ok=False
    def close(self):
        if self.temp_dir and os.path.isdir(self.temp_dir):
            try: shutil.rmtree(self.temp_dir)
            except Exception: pass
        self.temp_dir=None
    def load(self,path):
        self.close(); self.path=path; self.chunks=[]
        self.temp_dir=tempfile.mkdtemp(prefix="KorgPackage_HS_")
        total=os.path.getsize(path)
        if total<24: raise ValueError("File is too small to be a KORG package")
        with open(path,"rb") as f:
            self.expected_md5=f.read(16)
            h=hashlib.md5()
            while True:
                b=f.read(4*1024*1024)
                if not b: break
                h.update(b)
            self.calculated_md5=h.digest(); self.hash_ok=(self.expected_md5==self.calculated_md5)
            f.seek(16)
            while f.tell()<total:
                if total-f.tell()<8: break
                cid=r_u32le(f); size=r_u32le(f); payload=f.tell()
                if size<0 or payload+size>total: raise ValueError("Invalid chunk size at 0x%X"%payload)
                if cid==HEADER: c=HeaderChunk()
                elif cid in SYSTEM_PATHS: c=SystemFileChunk(cid)
                elif cid==INSTALLER_SCRIPT: c=InstallerScriptChunk()
                elif cid==DIRECTORY: c=DirectoryChunk()
                elif cid==FILE: c=FileChunk()
                elif cid==ROOT_FS: c=RootFSChunk()
                else: c=RawChunk(cid)
                c.source_size=size; c.load_payload(f,size,self.temp_dir); self.chunks.append(c)
                off=payload+size; rem=off%4
                if rem: off+=4-rem
                f.seek(off)
        return self
    def save(self,path):
        ordered=sorted(list(enumerate(self.chunks)), key=lambda it:(it[1].id,it[0]))
        with open(path,"w+b") as out:
            out.write(b"\x00"*16)
            for _,c in ordered:
                c.write_chunk(out)
                rem=out.tell()%4
                if rem: out.write(b"\x00"*(4-rem))
            out.flush(); out.seek(16)
            h=hashlib.md5()
            while True:
                b=out.read(4*1024*1024)
                if not b: break
                h.update(b)
            out.seek(0); out.write(h.digest()); out.flush()
        return path
    def summary(self):
        return [c.info() for c in self.chunks]
    def export_all(self,base):
        if not os.path.isdir(base): os.makedirs(base)
        outs=[]
        for c in self.chunks:
            try: outs.append(c.export_to(base))
            except Exception: pass
        return outs

def make_test_package(path):
    p=Package(); p.temp_dir=tempfile.mkdtemp(prefix="KPHSTest_")
    h=HeaderChunk()
    s=SystemFileChunk(SERVICE_APP); s.make_temp(p.temp_dir)
    open(s.data_path,"wb").write(b"PA600 SERVICE TEST\n")
    d=DirectoryChunk(); d.path="/omega_sys/test"
    f=FileChunk(); f.name="/omega_sys/test/hello.txt"; f.make_temp(p.temp_dir)
    open(f.data_path,"wb").write(b"hello pa600\n")
    r=RootFSChunk(); r.make_temp(p.temp_dir,".tar")
    open(r.data_path,"wb").write(b"FAKE_TAR_FOR_SELFTEST")
    p.chunks=[h,s,d,f,r]; p.save(path); p.close()
    q=Package().load(path)
    ok=q.hash_ok and len(q.chunks)==5
    q.close()
    return ok
