# NEW1 — KORG PA600 OS / FX PORT

Main repository for the KORG PA600 OS / FX PORT project.

## Structure
- `mac/KorgPackage_HighSierra_Port/` — High Sierra port for iMac 2011.
- `mac/PA600_OS_LAB/` — PA600 OS test lab for Mac.
- `source/` — editable source code.
- `vendor/` — original KorgPackage source/builds used as reference.
- `releases/` — ready test archives.
- `docs/` — reverse-engineering and project notes.

## Goal
Test OS/PKG/FX logic safely on iMac 2011 before moving verified components to the real KORG PA600.

## Safety
Keep the original PKG and a full recovery/eMMC backup before flashing modified packages to hardware.

KorgPackage-derived code remains under GPL-3.0.
