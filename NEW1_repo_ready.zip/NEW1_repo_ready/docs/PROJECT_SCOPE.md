# KORG PA600 FX PORT / OS workstream

Focus:
- inspect and edit PA600 PKG contents;
- develop and test a modified userspace/OS layer on Mac first;
- identify and port FX/DSP algorithms and parameter tables;
- build read-only diagnostics/dump tooling before any destructive hardware changes;
- keep original boot/recovery material untouched until the boot/update chain is understood.
