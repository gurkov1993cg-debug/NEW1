# FX/DSP Hunter — evidence strategy

The Hunter is designed to move from firmware contents to candidate effect implementation code without claiming more than the bytes prove.

## Confirmed external target vocabulary

Korg's Pa600 documentation describes 125 effect types and names/classes including reverb, chorus, flanger, phaser, delay, mastering limiter, compressor, exciter, overdrive/hi-gain, amp simulation and combined effects. These names and parameter labels are used only as search vocabulary.

## Evidence levels

1. **String hit** — exact printable bytes in the inspected object. This is direct evidence that the term exists in that binary/data object.
2. **Mapped string VA** — for ELF32 little-endian ARM, a string file offset is mapped through a validated `PT_LOAD` segment to its virtual address.
3. **Code xref candidate** — an executable ARM/Thumb instruction pattern resolves to the mapped string address. Implemented patterns currently include:
   - ARM `LDR` literal pool pointers;
   - ARM `ADR`-style `ADD/SUB Rd,pc,#imm` references;
   - ARM `MOVW` + nearby `MOVT` absolute-address materialization;
   - Thumb 16-bit literal `LDR`;
   - Thumb 16-bit PC-relative `ADR`.
4. **Nearest function candidate** — nearest preceding common ARM GCC `stmdb sp!, {...,lr}` or Thumb `push {...,lr}` prologue within a bounded search window.

A code xref is a strong navigation lead, not proof that the function implements the DSP mathematics. Full control/data-flow inspection is still required.

## Deliberate limits

- No guessed symbol names are invented for stripped binaries.
- No guessed UPD encryption/decryption is performed.
- A string used by UI/menu code may not be used by the DSP routine itself. The Hunter therefore reports the instruction and candidate function so call-graph tracing can continue from real addresses.
- Raw/non-ELF objects can still yield target strings, but reliable file-offset→runtime-address xrefs require a mapped executable format or a separately proven load map.
