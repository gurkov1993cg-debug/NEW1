# Korg Pa600 UPD forensic strategy

## Confirmed public facts

KORG's Pa600 support page states that the required update extension depends on the production lot: some units accept PKG and others accept UPD. The keyboard can report which format it expects when booted while holding INTRO 1. KORG has distributed Pa600 operating-system releases in these formats.

The exact UPD top-level container/encryption layout is not treated as known unless it can be demonstrated from bytes or a trustworthy implementation. KORG RE LAB therefore does not invent a UPD decryptor.

## What the parser does

The UPD parser is a read-only forensic carver. It scans the original byte stream once and only creates child objects when a format has enough independent structure to validate its extent:

- U-Boot legacy uImage: magic + declared payload size; the inspector also validates header CRC and data CRC.
- ELF: class/endianness plus bounded program/section tables and referenced file ranges.
- Flattened Device Tree: FDT magic and bounded `totalsize`.
- gzip: actual zlib/gzip decode to `Z_STREAM_END`, with a 256 MiB decoded safety cap.
- embedded Korg PKG: plausible chunk walk plus a valid outer package MD5.

The original UPD remains available as `UPD_CONTAINER` and is extracted byte-for-byte. Source-backed carved objects are not duplicated in memory unless analysis of that object is requested.

## Why this matters for Pa600 reverse engineering

The useful path is:

`UPD -> validated embedded object -> uImage / gzip / ELF / DTB -> kernel/app/hardware analysis -> ARM code and symbols`

This makes it possible to compare an official PKG and UPD release without first making an unsupported assumption about the UPD wrapper. Identical payload hashes found across the two containers can establish equivalence objectively.
