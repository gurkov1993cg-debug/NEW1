# Korg Pa PKG notes used by this implementation

The parser is intentionally conservative. It implements the publicly described Korg Pa package container and cross-checks the field order against the archived `Polprzewodnikowy/KorgPackage` source.

Top level:
- bytes 0..15: MD5 of all bytes from offset 16 to EOF
- then aligned chunks: LE32 id, LE32 payload size, payload, alignment to 4 bytes

Implemented chunk IDs from the source implementation:
1 header; 2-14 system files; 15 installer script; 16 directory; 17 file; 18 link/unknown; 19 root filesystem.

File compression:
- 0 raw
- 1 Korg block stream containing zlib-compressed blocks
- 16 encrypted (preserved, not guessed/decrypted)

The archived project's README contains an old table where file/link IDs are swapped; the source constants/classes are used here because they define what the parser actually executes.
