# Pa600 target map for FX/DSP reverse engineering

This file records targets already observed in project material extracted from a Pa600-family `arvon-c3.dtb` and kernel strings. KORG RE LAB now contains generic DTB and firmware-fingerprint analyzers so these observations can be reproduced from the actual binary rather than being hard-coded as conclusions.

## Confirmed observations from the extracted DTB used in this project

- Platform device tree contains TI DRA7-family peripherals.
- `mcasp@48468000`, compatible with `ti,dra7-mcasp-audio`, is marked `okay`; the other nearby McASP instances shown in the same extracted tree are disabled.
- DSP IOMMU nodes were observed at `0x40d01000` and `0x40d02000` with `ti,dra7-dsp-iommu` compatibility.
- A `dsp1_cma@88000000` shared-DMA-pool node is present and marked `okay`.
- The extracted kernel contained Linux/workhorse/KORG build fingerprints and an `arvon` release name.

## What to search next

1. DTB `remoteproc`, DSP, IOMMU, CMA, mailbox and reserved-memory nodes.
2. Kernel strings referring to DSP firmware filenames, remoteproc loading, ALSA, McASP, mixer and codec setup.
3. ELF applications/libraries with symbols or strings containing `effect`, `fx`, `reverb`, `delay`, `chorus`, `dsp`, `audio`, `mixer`, `pcm` and `codec`.
4. Cross-references from those strings/symbols into ARM functions.
5. Differences between Pa600 OS versions around the same executable/resource path.

The active McASP and DSP-memory observations are routing clues; they do not by themselves prove where the musical FX algorithms execute. That must be established from executable/DSP firmware evidence.


## Confirmed evidence from a real Pa600QT package-update log

A public Pa600QT failure log shows the Korg updater itself successfully validating a PKG, extracting `/emmc/update/uImage`, `/emmc/update/ramdisk.gz`, `/emmc/update/lfo-pkg-install` and `/emmc/update/lfo-pkg-install.xml`, then mounting `/dev/mmcblk0p7` on `/emmc/omega_sys`. The same log reports write requests for `/emmc/kernel`, `/emmc/omega_sys` and `/emmc/rootfs`, and formats `rootfs` as EXT3 with 4096-byte blocks.

The root filesystem listing in that update log contains Linux module trees named `2.6.32-andoria-release` and `2.6.32-andoria-debug`. High-value reverse-analysis targets named in the log include:

- `kr_epf_audio_ctrl.ko` — highest-priority audio-control kernel-module target.
- `kr_epf_fpga.ko` — platform FPGA interface target.
- `kr_epf_i2c_bus.ko` — platform I2C target.
- `kr_epf_andoria_plat.ko` — Andoria platform target.
- `kr_epf_core.ko` — platform core target.
- `snd_tty_midi.ko` — MIDI-related kernel module.

These filenames are concrete evidence of the Pa600 platform/audio control stack. They do **not** by themselves prove that the 125 musical FX algorithms execute inside `kr_epf_audio_ctrl.ko`; KORG RE LAB therefore treats them as high-priority inspection targets and separately requires FX strings/symbols/code cross-references before claiming an effect implementation.
