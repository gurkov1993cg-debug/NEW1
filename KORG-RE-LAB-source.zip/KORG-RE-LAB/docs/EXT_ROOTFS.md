# Pa600 EXT rootfs inspection

A public Pa600QT update log records the updater formatting `/emmc/rootfs` as EXT3 using 4096-byte blocks. KORG RE LAB therefore recognizes a standard Linux EXT superblock at byte offset 1024 when magic `0xEF53` is present.

The inspector reports:

- EXT2/EXT3/EXT4-family inference from standard feature bits;
- volume label and last-mounted path;
- block size, block/inode counts and group sizes;
- journal and extents feature presence.

This is filesystem metadata inspection only. The tool does not mount the image or modify it.
