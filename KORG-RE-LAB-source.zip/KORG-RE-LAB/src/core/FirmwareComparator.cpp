#include "FirmwareComparator.h"
#include "Md5.h"
#include <algorithm>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#include <vector>
namespace krl { namespace {
struct Ref{const uint8_t*p=nullptr;size_t n=0;};
static Ref ref(const Analysis&a,const Chunk&c){if(c.decoded)return{c.decodedData.data(),c.decodedData.size()};if(!c.rawPayload.empty())return{c.rawPayload.data(),c.rawPayload.size()};if(c.sourceBacked&&c.sourceOffset<=a.wholeFile.size()&&c.sourceSize<=a.wholeFile.size()-c.sourceOffset)return{a.wholeFile.data()+(size_t)c.sourceOffset,(size_t)c.sourceSize};return{};}
static std::string hash(const Analysis&a,const Chunk&c){auto r=ref(a,c);return r.p?md5Hex(r.p,r.n):std::string();}
static std::string key(const Chunk&c,size_t ordinal){if(!c.virtualPath.empty()&&c.typeName.rfind("CARVED_",0)!=0&&c.typeName!="UPD_CONTAINER")return c.typeName+"|"+c.virtualPath;std::ostringstream o;o<<c.typeName<<"|#"<<ordinal;return o.str();}
static size_t firstDiff(Ref a,Ref b){size_t n=std::min(a.n,b.n);for(size_t i=0;i<n;++i)if(a.p[i]!=b.p[i])return i;return n;}
static std::string head(const Analysis&a){std::ostringstream o;o<<a.kindName<<" | "<<a.fileSize<<" bytes";if(a.header.present)o<<" | "<<a.header.systemType<<" | "<<a.header.buildSystem1<<"/"<<a.header.buildSystem2<<" | "<<a.header.date<<" "<<a.header.time;return o.str();}
}
std::string FirmwareComparator::compare(const Analysis&a,const Analysis&b){
 std::ostringstream o;o<<"KORG RE LAB — Firmware Compare\n\nA: "<<a.sourcePath<<"\n   "<<head(a)<<"\nB: "<<b.sourcePath<<"\n   "<<head(b)<<"\n\n";std::string ah=a.wholeFile.empty()?std::string():md5Hex(a.wholeFile),bh=b.wholeFile.empty()?std::string():md5Hex(b.wholeFile);o<<"Whole-file MD5\nA: "<<ah<<"\nB: "<<bh<<"\nIdentical: "<<(!ah.empty()&&ah==bh?"YES":"NO")<<"\n\n";
 std::map<std::string,size_t> ma,mb;std::map<std::string,size_t> ordA,ordB;for(size_t i=0;i<a.chunks.size();++i){size_t n=ordA[a.chunks[i].typeName]++;ma[key(a.chunks[i],n)]=i;}for(size_t i=0;i<b.chunks.size();++i){size_t n=ordB[b.chunks[i].typeName]++;mb[key(b.chunks[i],n)]=i;}
 std::set<std::string> keys;for(auto&x:ma)keys.insert(x.first);for(auto&x:mb)keys.insert(x.first);size_t same=0,changed=0,onlyA=0,onlyB=0;o<<"Object comparison\n";for(auto&k:keys){auto ia=ma.find(k),ib=mb.find(k);if(ia==ma.end()){++onlyB;o<<"ONLY B  "<<k<<"\n";continue;}if(ib==mb.end()){++onlyA;o<<"ONLY A  "<<k<<"\n";continue;}const Chunk&ca=a.chunks[ia->second];const Chunk&cb=b.chunks[ib->second];auto ra=ref(a,ca),rb=ref(b,cb);std::string ha=hash(a,ca),hb=hash(b,cb);if(!ha.empty()&&ha==hb&&ra.n==rb.n){++same;continue;}++changed;o<<"CHANGED "<<k<<"\n  A size="<<ra.n<<" md5="<<ha<<"\n  B size="<<rb.n<<" md5="<<hb;if(ra.p&&rb.p){size_t d=firstDiff(ra,rb);o<<"\n  first byte difference: 0x"<<std::hex<<std::uppercase<<d<<std::dec;}o<<"\n";}
 o<<"\nSummary: unchanged="<<same<<" changed="<<changed<<" only-A="<<onlyA<<" only-B="<<onlyB<<"\n\n";
 std::multimap<std::string,size_t> haMap,hbMap;for(size_t i=0;i<a.chunks.size();++i){auto h=hash(a,a.chunks[i]);if(!h.empty()&&ref(a,a.chunks[i]).n>=32)haMap.emplace(h,i);}for(size_t i=0;i<b.chunks.size();++i){auto h=hash(b,b.chunks[i]);if(!h.empty()&&ref(b,b.chunks[i]).n>=32)hbMap.emplace(h,i);}size_t cross=0;o<<"Cross-container identical payloads\n";std::set<std::string> emitted;for(auto&x:haMap){auto rg=hbMap.equal_range(x.first);for(auto it=rg.first;it!=rg.second&&cross<200;++it){const auto&ca=a.chunks[x.second];const auto&cb=b.chunks[it->second];std::string tag=std::to_string(x.second)+":"+std::to_string(it->second);if(!emitted.insert(tag).second)continue;o<<"A#"<<x.second<<" "<<ca.typeName<<" "<<ca.virtualPath<<"  ==  B#"<<it->second<<" "<<cb.typeName<<" "<<cb.virtualPath<<"  md5="<<x.first<<"\n";++cross;}}
 if(!cross) o<<"(no identical object payloads >= 32 bytes found)\n";
 if(cross>=200) o<<"... match limit reached ...\n";
 return o.str();
}
}
