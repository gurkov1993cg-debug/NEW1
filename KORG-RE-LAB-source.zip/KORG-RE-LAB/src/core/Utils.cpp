#include "Utils.h"
#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <sys/stat.h>
#include <sys/types.h>

namespace krl {
uint16_t le16(const uint8_t* p){ return uint16_t(p[0]) | (uint16_t(p[1])<<8); }
uint32_t le32(const uint8_t* p){ return uint32_t(p[0]) | (uint32_t(p[1])<<8) | (uint32_t(p[2])<<16) | (uint32_t(p[3])<<24); }
uint32_t be32(const uint8_t* p){ return (uint32_t(p[0])<<24) | (uint32_t(p[1])<<16) | (uint32_t(p[2])<<8) | uint32_t(p[3]); }
uint64_t le64(const uint8_t* p){ uint64_t v=0; for(int i=7;i>=0;--i) v=(v<<8)|p[i]; return v; }

std::string hex(const uint8_t* p, size_t n){
    std::ostringstream o; o<<std::hex<<std::setfill('0')<<std::uppercase;
    for(size_t i=0;i<n;++i) o<<std::setw(2)<<unsigned(p[i]);
    return o.str();
}

std::string hexDump(const std::vector<uint8_t>& data, uint64_t baseOffset, size_t maxBytes){
    const size_t n=std::min(data.size(), maxBytes);
    std::ostringstream o; o<<std::hex<<std::uppercase<<std::setfill('0');
    for(size_t off=0; off<n; off+=16){
        o<<std::setw(8)<<(baseOffset+off)<<"  ";
        for(size_t i=0;i<16;++i){ if(off+i<n) o<<std::setw(2)<<unsigned(data[off+i])<<' '; else o<<"   "; if(i==7)o<<' '; }
        o<<" |";
        for(size_t i=0;i<16 && off+i<n;++i){ unsigned char c=data[off+i]; o<<(std::isprint(c)?char(c):'.'); }
        o<<"|\n";
    }
    if(data.size()>n) o<<"\n... truncated, showing "<<std::dec<<n<<" of "<<data.size()<<" bytes ...\n";
    return o.str();
}

std::vector<std::string> asciiStrings(const std::vector<uint8_t>& data, size_t minLen, size_t maxCount){
    std::vector<std::string> out; std::string cur; size_t start=0;
    for(size_t i=0;i<=data.size();++i){
        bool ok = i<data.size() && (data[i]==9 || data[i]==32 || (data[i]>=33 && data[i]<=126));
        if(ok){ if(cur.empty()) start=i; cur.push_back(char(data[i])); }
        else { if(cur.size()>=minLen){ std::ostringstream s; s<<"0x"<<std::hex<<std::uppercase<<start<<"  "<<cur; out.push_back(s.str()); if(out.size()>=maxCount) break; } cur.clear(); }
    }
    return out;
}

std::string sanitizeRelativePath(const std::string& path){
    std::string p=path; std::replace(p.begin(),p.end(),'\\','/');
    while(!p.empty() && p.front()=='/') p.erase(p.begin());
    std::vector<std::string> parts; std::stringstream ss(p); std::string item;
    while(std::getline(ss,item,'/')){ if(item.empty()||item==".") continue; if(item=="..") { if(!parts.empty()) parts.pop_back(); continue; } parts.push_back(item); }
    std::ostringstream o; for(size_t i=0;i<parts.size();++i){ if(i)o<<'/'; o<<parts[i]; }
    return o.str();
}
std::string baseName(const std::string& p){ auto x=p.find_last_of("/\\"); return x==std::string::npos?p:p.substr(x+1); }
std::string parentPath(const std::string& p){ auto x=p.find_last_of("/\\"); return x==std::string::npos?std::string():p.substr(0,x); }
std::string joinPath(const std::string& a,const std::string& b){ if(a.empty())return b; if(b.empty())return a; char c=a.back(); return (c=='/'||c=='\\')?a+b:a+"/"+b; }

static bool mkdirOne(const std::string& p){ if(p.empty())return true; if(::mkdir(p.c_str(),0755)==0)return true; return errno==EEXIST; }
bool makeDirectoriesForFile(const std::string& filePath){
    std::string p=parentPath(filePath); if(p.empty())return true;
    std::string cur; size_t i=0;
    if(!p.empty()&&p[0]=='/'){cur="/";i=1;}
    for(;i<=p.size();++i){ if(i==p.size()||p[i]=='/'){ if(!cur.empty()&&!mkdirOne(cur))return false; } else { cur.push_back(p[i]); if(i+1<p.size()&&p[i+1]=='/'&&!cur.empty()&&cur.back()!='/') cur.push_back('/'); } }
    return true;
}

bool writeFile(const std::string& path,const std::vector<uint8_t>& data,std::string& error){
    if(!makeDirectoriesForFile(path)){ error="Could not create directory for: "+path; return false; }
    std::ofstream f(path,std::ios::binary); if(!f){error="Could not open for writing: "+path;return false;} if(!data.empty())f.write((const char*)data.data(),std::streamsize(data.size())); if(!f){error="Write failed: "+path;return false;} return true;
}
bool writeFileRange(const std::string& path,const std::vector<uint8_t>& data,uint64_t offset,uint64_t size,std::string& error){
    if(offset>data.size() || size>data.size()-offset){ error="Requested source range is outside input file"; return false; }
    if(!makeDirectoriesForFile(path)){ error="Could not create directory for: "+path; return false; }
    std::ofstream f(path,std::ios::binary); if(!f){error="Could not open for writing: "+path;return false;}
    const size_t chunk=1024u*1024u; uint64_t done=0;
    while(done<size){ size_t n=(size_t)std::min<uint64_t>(chunk,size-done); f.write((const char*)data.data()+(size_t)(offset+done),std::streamsize(n)); if(!f){error="Write failed: "+path;return false;} done+=n; }
    return true;
}
std::vector<uint8_t> readFile(const std::string& path,std::string& error){
    std::ifstream f(path,std::ios::binary); if(!f){error="Could not open: "+path;return{};} f.seekg(0,std::ios::end); auto n=f.tellg(); if(n<0){error="Could not determine size";return{};} f.seekg(0); std::vector<uint8_t> d((size_t)n); if(!d.empty())f.read((char*)d.data(),n); if(!f&&n){error="Read failed";return{};} return d;
}
} // namespace krl
