#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace krl {
uint16_t le16(const uint8_t* p);
uint32_t le32(const uint8_t* p);
uint32_t be32(const uint8_t* p);
uint64_t le64(const uint8_t* p);
std::string hex(const uint8_t* p, size_t n);
std::string hexDump(const std::vector<uint8_t>& data, uint64_t baseOffset = 0, size_t maxBytes = 4096);
std::vector<std::string> asciiStrings(const std::vector<uint8_t>& data, size_t minLen = 4, size_t maxCount = 1000);
std::string sanitizeRelativePath(const std::string& path);
bool writeFile(const std::string& path, const std::vector<uint8_t>& data, std::string& error);
bool writeFileRange(const std::string& path, const std::vector<uint8_t>& data, uint64_t offset, uint64_t size, std::string& error);
std::vector<uint8_t> readFile(const std::string& path, std::string& error);
std::string baseName(const std::string& path);
std::string parentPath(const std::string& path);
std::string joinPath(const std::string& a, const std::string& b);
bool makeDirectoriesForFile(const std::string& filePath);
}
