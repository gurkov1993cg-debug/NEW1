#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
namespace krl { std::string md5Hex(const uint8_t* data, size_t size); inline std::string md5Hex(const std::vector<uint8_t>& d){return md5Hex(d.data(),d.size());} }
