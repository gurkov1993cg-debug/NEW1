#include "Analyzer.h"
#include "Utils.h"
#include "korg/PkgParser.h"
#include "korg/UpdParser.h"
#include "reverse/BinaryInspector.h"
#include "reverse/FxHunter.h"
#include "reverse/TargetProfiler.h"
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <sstream>

namespace krl {
static std::string lower(std::string s){for(char&c:s)c=char(std::tolower((unsigned char)c));return s;}
static std::string extOf(const std::string&p){auto x=p.find_last_of('.');return x==std::string::npos?std::string():lower(p.substr(x));}

bool Analyzer::open(const std::string& path,std::string& error){
 auto bytes=readFile(path,error); if(!error.empty())return false; a_=Analysis{};
 if(PkgParser::looksLikePkg(bytes)){if(!PkgParser::parse(path,bytes,a_,error))return false;return true;}
 std::string ex=extOf(path);
 if(ex==".upd") return UpdParser::parse(path,bytes,a_,error);
 a_.sourcePath=path;a_.fileSize=bytes.size();a_.wholeFile=bytes;
 std::string id=BinaryInspector::identify(bytes);
 if(id.find("ELF")==0){a_.kind=ContainerKind::Elf;a_.kindName=id;} else if(id.find("U-Boot")==0){a_.kind=ContainerKind::UImage;a_.kindName=id;} else {a_.kind=ContainerKind::RawBinary;a_.kindName=id;}
 Chunk c;c.id=0;c.typeName=a_.kindName;c.virtualPath="/"+baseName(path);c.payloadSize=(uint32_t)std::min<uint64_t>(bytes.size(),0xffffffffu);c.sourceBacked=true;c.sourceOffset=0;c.sourceSize=bytes.size();c.info="Raw forensic object. No destructive transformation was applied.\n";a_.chunks.push_back(std::move(c));
 return true;
}

std::string Analyzer::summary() const{
 std::ostringstream o;o<<"KORG RE LAB — OS Inspector\n\nSource: "<<a_.sourcePath<<"\nSize: "<<a_.fileSize<<" bytes\nDetected: "<<a_.kindName<<"\n";
 if(a_.packageDigestPresent)o<<"Package MD5 stored:     "<<a_.packageDigestStored<<"\nPackage MD5 calculated: "<<a_.packageDigestCalculated<<"\nIntegrity: "<<(a_.packageDigestValid?"VALID":"MISMATCH")<<"\n";
 if(a_.header.present)o<<"\nKorg package header\nSystem: "<<a_.header.systemType<<"\nBuild: "<<a_.header.buildSystem1<<" / "<<a_.header.buildSystem2<<"\nCreated: "<<a_.header.date<<" "<<a_.header.time<<"\nPackage kind: "<<(a_.header.packageType==2?"UPDATE":a_.header.packageType==3?"FULL INSTALLATION":"UNKNOWN")<<"\n";
 o<<"\nObjects/chunks: "<<a_.chunks.size()<<"\n";for(size_t i=0;i<a_.chunks.size();++i){const auto&c=a_.chunks[i];o<<std::setw(3)<<i<<"  0x"<<std::hex<<std::uppercase<<std::setw(8)<<std::setfill('0')<<c.headerOffset<<std::dec<<std::setfill(' ')<<"  "<<c.typeName<<"  "<<(c.virtualPath.empty()?"(no path)":c.virtualPath)<<"  ["<<c.payloadSize<<" bytes]"<<(c.encrypted?"  ENCRYPTED":"")<<"\n";}
 if(!a_.warnings.empty()){o<<"\nWarnings\n";for(const auto&w:a_.warnings)o<<"- "<<w<<"\n";}return o.str();
}

std::string Analyzer::chunkReport(size_t index) const{
 if(index>=a_.chunks.size()) return "No object selected.";
 const auto& c=a_.chunks[index]; const std::vector<uint8_t>* d=nullptr; std::vector<uint8_t> view; bool partial=false;
 if(c.decoded)d=&c.decodedData;else if(!c.rawPayload.empty())d=&c.rawPayload;else if(c.sourceBacked){
   if(c.sourceOffset==0&&c.sourceSize==a_.wholeFile.size())d=&a_.wholeFile;
   else if(c.sourceOffset<=a_.wholeFile.size()&&c.sourceSize<=a_.wholeFile.size()-c.sourceOffset){size_t take=(size_t)std::min<uint64_t>(c.sourceSize,128ull*1024ull*1024ull);view.assign(a_.wholeFile.begin()+(size_t)c.sourceOffset,a_.wholeFile.begin()+(size_t)c.sourceOffset+take);partial=take<c.sourceSize;d=&view;}
 }
 if(!d)d=&a_.wholeFile;
 std::ostringstream o;o<<c.info;if(c.sourceBacked)o<<"Source range: 0x"<<std::hex<<std::uppercase<<c.sourceOffset<<"..0x"<<(c.sourceOffset+c.sourceSize)<<std::dec<<" ("<<c.sourceSize<<" bytes)\n";if(partial)o<<"Analysis view is capped at 128 MiB; extraction still preserves the full source range.\n";o<<"\nDetected payload: "<<BinaryInspector::identify(*d)<<"\n\n";
 auto u=BinaryInspector::uImageReport(*d);if(!u.empty())o<<u<<"\n";auto e=BinaryInspector::elfReport(*d);if(!e.empty()){o<<e<<"\n";o<<BinaryInspector::elfSymbolReport(*d)<<"\n";}auto dt=BinaryInspector::dtbReport(*d);if(!dt.empty())o<<dt<<"\n";auto ext=BinaryInspector::extFilesystemReport(*d);if(!ext.empty())o<<ext<<"\n";o<<BinaryInspector::firmwareFingerprintReport(*d)<<"\n";o<<BinaryInspector::signaturesReport(*d)<<"\n";
 if(c.typeName=="UPD_CONTAINER")o<<BinaryInspector::entropyReport(*d,4u*1024u*1024u,24)<<"\n";
 if(c.typeName=="CARVED_KORG_PKG"&&!partial&&PkgParser::looksLikePkg(*d)){Analysis nested;std::string pe;if(PkgParser::parse(c.virtualPath,*d,nested,pe)){o<<"Embedded Korg PKG\nIntegrity: "<<(nested.packageDigestValid?"VALID":"MISMATCH")<<"\nChunks: "<<nested.chunks.size()<<"\n";if(nested.header.present)o<<"System: "<<nested.header.systemType<<"\nBuild: "<<nested.header.buildSystem1<<" / "<<nested.header.buildSystem2<<"\n";o<<"\n";}}
 o<<"Strings (first 300)\n";auto ss=asciiStrings(*d,4,300);for(auto&s:ss)o<<s<<"\n";if(ss.empty())o<<"(none)\n";
 o<<"\nHex preview\n"<<hexDump(*d,c.sourceBacked?c.sourceOffset:0,8192);
 if((!e.empty() && e.find("Machine: 40")!=std::string::npos)||!u.empty())o<<"\nDisassembly preview\n"<<BinaryInspector::disassemblyPreview(*d);
 return o.str();
}

std::string Analyzer::fxReport(size_t index) const{
 if(index>=a_.chunks.size()) return "No object selected.";
 const auto& c=a_.chunks[index]; const std::vector<uint8_t>* d=nullptr; std::vector<uint8_t> view;
 if(c.decoded)d=&c.decodedData;else if(!c.rawPayload.empty())d=&c.rawPayload;else if(c.sourceBacked&&c.sourceOffset<=a_.wholeFile.size()&&c.sourceSize<=a_.wholeFile.size()-c.sourceOffset){size_t take=(size_t)std::min<uint64_t>(c.sourceSize,256ull*1024ull*1024ull);view.assign(a_.wholeFile.begin()+(size_t)c.sourceOffset,a_.wholeFile.begin()+(size_t)c.sourceOffset+take);d=&view;}
 if(!d)d=&a_.wholeFile;
 std::ostringstream o;o<<"Object #"<<index<<"  "<<c.typeName<<"  "<<c.virtualPath<<"\n\n"<<FxHunter::report(*d);return o.str();
}


std::string Analyzer::targetReport() const{
 return TargetProfiler::report(a_);
}

bool Analyzer::extractChunk(size_t index,const std::string& root,std::string& error) const{
 if(index>=a_.chunks.size()){error="Invalid selection";return false;}const auto&c=a_.chunks[index];if(c.typeName=="DIRECTORY"){std::string rel=sanitizeRelativePath(c.virtualPath);if(rel.empty())return true;return makeDirectoriesForFile(joinPath(root,rel+"/.krl_dir_probe"));}std::string rel=sanitizeRelativePath(c.virtualPath);if(rel.empty())rel="chunk_"+std::to_string(index)+"_id_"+std::to_string(c.id)+".bin";if(c.encrypted)rel+=".encrypted";std::string dst=joinPath(root,rel);if(c.decoded)return writeFile(dst,c.decodedData,error);if(!c.rawPayload.empty())return writeFile(dst,c.rawPayload,error);if(c.sourceBacked)return writeFileRange(dst,a_.wholeFile,c.sourceOffset,c.sourceSize,error);return writeFile(dst,a_.wholeFile,error);
}

bool Analyzer::extractAll(const std::string& root,std::string& error) const{for(size_t i=0;i<a_.chunks.size();++i){if(!extractChunk(i,root,error))return false;}return true;}
}
