#pragma once
#include "Model.h"
#include <string>
namespace krl { class FirmwareComparator { public: static std::string compare(const Analysis& a,const Analysis& b); }; }
