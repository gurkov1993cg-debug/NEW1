#pragma once
#include "Model.h"
#include <string>
namespace krl {
class Analyzer {
public:
 bool open(const std::string& path,std::string& error);
 const Analysis& result() const { return a_; }
 std::string summary() const;
 std::string chunkReport(size_t index) const;
 std::string fxReport(size_t index) const;
 std::string targetReport() const;
 bool extractChunk(size_t index,const std::string& outputRoot,std::string& error) const;
 bool extractAll(const std::string& outputRoot,std::string& error) const;
private: Analysis a_;
};
}
