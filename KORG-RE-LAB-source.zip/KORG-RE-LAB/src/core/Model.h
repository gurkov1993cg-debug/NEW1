#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace krl {

enum class ContainerKind { Unknown, KorgPkg, KorgUpd, RawBinary, Elf, UImage };

struct Chunk {
    uint32_t id = 0;
    uint32_t payloadSize = 0;
    uint64_t headerOffset = 0;
    uint64_t payloadOffset = 0;
    std::string typeName;
    std::string virtualPath;
    std::string info;
    std::vector<uint8_t> rawPayload;
    std::vector<uint8_t> decodedData;
    bool decoded = false;
    bool encrypted = false;
    bool sourceBacked = false;
    uint64_t sourceOffset = 0;
    uint64_t sourceSize = 0;
};

struct PackageHeader {
    bool present = false;
    uint8_t libVersion[4] = {0,0,0,0};
    uint32_t packageType = 0;
    uint16_t unknownA = 0;
    uint16_t unknownB = 0;
    std::string systemType;
    std::string buildSystem1;
    std::string buildSystem2;
    std::string date;
    std::string time;
    std::string packageType1;
    std::string packageType2;
};

struct Analysis {
    std::string sourcePath;
    ContainerKind kind = ContainerKind::Unknown;
    std::string kindName;
    uint64_t fileSize = 0;
    bool packageDigestPresent = false;
    bool packageDigestValid = false;
    std::string packageDigestStored;
    std::string packageDigestCalculated;
    PackageHeader header;
    std::vector<Chunk> chunks;
    std::vector<uint8_t> wholeFile;
    std::vector<std::string> warnings;
};

} // namespace krl
