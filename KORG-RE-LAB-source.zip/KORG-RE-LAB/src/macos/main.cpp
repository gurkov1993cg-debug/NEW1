#include "core/Analyzer.h"
#include "core/FirmwareComparator.h"
#include "core/Utils.h"
#include <objc/message.h>
#include <objc/runtime.h>
#include <cfloat>
#include <cstdint>
#include <memory>
#include <sstream>
#include <string>

using Obj = id;
struct NSPointK { double x,y; };
struct NSSizeK { double width,height; };
struct NSRectK { NSPointK origin; NSSizeK size; };
static NSRectK rect(double x,double y,double w,double h){ return {{x,y},{w,h}}; }

static SEL S(const char* n){ return sel_registerName(n); }
template<class R, class... A> static R M(Obj o,const char* s,A... a){ using F=R(*)(Obj,SEL,A...); return reinterpret_cast<F>(objc_msgSend)(o,S(s),a...); }
static Obj C(const char* n){ return reinterpret_cast<Obj>(objc_getClass(n)); }
static Obj str(const std::string& s){ return M<Obj>(C("NSString"),"stringWithUTF8String:",s.c_str()); }
static Obj str(const char* s){ return M<Obj>(C("NSString"),"stringWithUTF8String:",s); }
static std::string pathString(Obj ns){ if(!ns)return{}; const char* p=M<const char*>(ns,"fileSystemRepresentation"); return p?std::string(p):std::string(); }

struct AppState {
    std::unique_ptr<krl::Analyzer> analyzer{new krl::Analyzer()};
    Obj window=nullptr;
    Obj popup=nullptr;
    Obj text=nullptr;
    Obj status=nullptr;
    Obj extractSelected=nullptr;
};
static AppState* g=nullptr;
static std::string gPendingPath;

static void setText(const std::string& s){ if(g&&g->text) M<void>(g->text,"setString:",str(s)); }
static void setStatus(const std::string& s){ if(g&&g->status) M<void>(g->status,"setStringValue:",str(s)); }
static void alertBox(const char* title,const std::string& detail){ Obj a=M<Obj>(C("NSAlert"),"alloc");a=M<Obj>(a,"init");M<void>(a,"setMessageText:",str(title));M<void>(a,"setInformativeText:",str(detail));M<long long>(a,"runModal"); }

static Obj makeButton(Obj target,const char* title,double x,SEL action){
    Obj b=M<Obj>(C("NSButton"),"alloc"); b=M<Obj>(b,"initWithFrame:",rect(x,742,118,30));
    M<void>(b,"setTitle:",str(title)); M<void>(b,"setBezelStyle:",(long long)1); M<void>(b,"setTarget:",target); M<void>(b,"setAction:",action); return b;
}
static Obj makeLabel(const char* text,NSRectK r,double fontSize){
    Obj t=M<Obj>(C("NSTextField"),"alloc");t=M<Obj>(t,"initWithFrame:",r);M<void>(t,"setStringValue:",str(text));M<void>(t,"setBezeled:",(signed char)0);M<void>(t,"setDrawsBackground:",(signed char)0);M<void>(t,"setEditable:",(signed char)0);M<void>(t,"setSelectable:",(signed char)0);Obj f=M<Obj>(C("NSFont"),"systemFontOfSize:",fontSize);if(f)M<void>(t,"setFont:",f);return t;
}
static void refreshPopup(){
    if(!g||!g->popup)return; M<void>(g->popup,"removeAllItems");
    const auto& a=g->analyzer->result();
    for(size_t i=0;i<a.chunks.size();++i){const auto& c=a.chunks[i];std::ostringstream o;o<<i<<"  "<<c.typeName;if(c.encrypted)o<<" [ENCRYPTED]";if(!c.virtualPath.empty())o<<"  "<<c.virtualPath;M<void>(g->popup,"addItemWithTitle:",str(o.str()));}
    M<void>(g->extractSelected,"setEnabled:",(signed char)(!a.chunks.empty()));
}
static void loadPath(const std::string& p){
    std::string err;if(!g->analyzer->open(p,err)){alertBox("Could not open firmware",err);return;}refreshPopup();setText(g->analyzer->summary());std::ostringstream s;s<<krl::baseName(p)<<" — "<<g->analyzer->result().fileSize<<" bytes — "<<g->analyzer->result().chunks.size()<<" objects";setStatus(s.str());
}
static std::string chooseFolder(){
    Obj p=M<Obj>(C("NSOpenPanel"),"openPanel");M<void>(p,"setCanChooseFiles:",(signed char)0);M<void>(p,"setCanChooseDirectories:",(signed char)1);M<void>(p,"setCanCreateDirectories:",(signed char)1);M<void>(p,"setAllowsMultipleSelection:",(signed char)0);M<void>(p,"setPrompt:",str("Extract"));if(M<long long>(p,"runModal")!=1)return{};Obj u=M<Obj>(p,"URL");Obj path=M<Obj>(u,"path");return pathString(path);
}

static void appDidFinish(Obj self,SEL,Obj){
    Obj w=M<Obj>(C("NSWindow"),"alloc");
    const unsigned long long style=(1ull<<0)|(1ull<<1)|(1ull<<2)|(1ull<<3);
    w=M<Obj>(w,"initWithContentRect:styleMask:backing:defer:",rect(0,0,1240,780),style,(unsigned long long)2,(signed char)0);g->window=w;
    M<void>(w,"setTitle:",str("KORG RE LAB — OS Inspector"));M<void>(w,"center");M<void>(w,"setMinSize:",NSSizeK{900,580});Obj root=M<Obj>(w,"contentView");
    Obj open=makeButton(self,"Open Korg OS…",12,S("openFirmware:"));M<void>(root,"addSubview:",open);
    Obj summary=makeButton(self,"Summary",135,S("showSummary:"));M<void>(root,"addSubview:",summary);
    Obj fx=makeButton(self,"FX/DSP Hunt",258,S("showFx:"));M<void>(root,"addSubview:",fx);
    Obj targets=makeButton(self,"Pa600 Targets",381,S("showTargets:"));M<void>(root,"addSubview:",targets);
    g->extractSelected=makeButton(self,"Extract Selected…",504,S("extractSelected:"));M<void>(g->extractSelected,"setEnabled:",(signed char)0);M<void>(root,"addSubview:",g->extractSelected);
    Obj all=makeButton(self,"Extract All…",627,S("extractAll:"));M<void>(root,"addSubview:",all);
    Obj cmp=makeButton(self,"Compare OS…",750,S("compareFirmware:"));M<void>(root,"addSubview:",cmp);

    Obj popup=M<Obj>(C("NSPopUpButton"),"alloc");popup=M<Obj>(popup,"initWithFrame:pullsDown:",rect(873,742,352,30),(signed char)0);g->popup=popup;M<void>(popup,"setTarget:",self);M<void>(popup,"setAction:",S("selectionChanged:"));M<void>(root,"addSubview:",popup);

    Obj scroll=M<Obj>(C("NSScrollView"),"alloc");scroll=M<Obj>(scroll,"initWithFrame:",rect(10,35,1220,695));M<void>(scroll,"setHasVerticalScroller:",(signed char)1);M<void>(scroll,"setHasHorizontalScroller:",(signed char)1);M<void>(scroll,"setBorderType:",(unsigned long long)2);M<void>(scroll,"setAutoresizingMask:",(unsigned long long)(2|16));
    Obj tv=M<Obj>(C("NSTextView"),"alloc");tv=M<Obj>(tv,"initWithFrame:",rect(0,0,1210,695));g->text=tv;M<void>(tv,"setEditable:",(signed char)0);M<void>(tv,"setSelectable:",(signed char)1);M<void>(tv,"setRichText:",(signed char)0);M<void>(tv,"setHorizontallyResizable:",(signed char)1);M<void>(tv,"setVerticallyResizable:",(signed char)1);Obj font=M<Obj>(C("NSFont"),"userFixedPitchFontOfSize:",12.0);if(font)M<void>(tv,"setFont:",font);M<void>(scroll,"setDocumentView:",tv);M<void>(root,"addSubview:",scroll);
    g->status=makeLabel("Open a Korg OS file (.PKG or .UPD) to inspect it.",rect(12,7,1215,20),11.0);M<void>(g->status,"setAutoresizingMask:",(unsigned long long)2);M<void>(root,"addSubview:",g->status);

    M<void>(w,"makeKeyAndOrderFront:",(Obj)nullptr);Obj app=M<Obj>(C("NSApplication"),"sharedApplication");M<void>(app,"activateIgnoringOtherApps:",(signed char)1);
    setText("KORG RE LAB — OS Inspector\n\nOpen a Korg Pa operating-system file.\n\nSupported analysis:\n• PKG container/chunks and integrity\n• RAW / Korg ZLIB extraction\n• encrypted payload identification\n• uImage / ELF metadata\n• embedded signature scan\n• strings and hex view\n• ARM / Thumb disassembly preview\n• validated UPD object carving\n• DTB hardware map and firmware fingerprints\n• ELF audio/FX symbol scan\n• ARM/Thumb FX string cross-references\n• Pa600 target profiler (audio/FX/DSP evidence)\n• EXT2/3/4 rootfs superblock inspection\n• firmware / PKG↔UPD comparison\n");
    if(!gPendingPath.empty()) loadPath(gPendingPath);
}
static signed char shouldTerminate(Obj,SEL,Obj){return 1;}
static void openFirmware(Obj,SEL,Obj){Obj p=M<Obj>(C("NSOpenPanel"),"openPanel");M<void>(p,"setCanChooseFiles:",(signed char)1);M<void>(p,"setCanChooseDirectories:",(signed char)0);M<void>(p,"setAllowsMultipleSelection:",(signed char)0);M<void>(p,"setMessage:",str("Select a Korg operating-system package or extracted firmware binary."));if(M<long long>(p,"runModal")!=1)return;Obj u=M<Obj>(p,"URL");loadPath(pathString(M<Obj>(u,"path")));}
static void showSummary(Obj,SEL,Obj){if(g)setText(g->analyzer->summary());}
static void showFx(Obj,SEL,Obj){if(!g)return;long long i=M<long long>(g->popup,"indexOfSelectedItem");if(i<0||(size_t)i>=g->analyzer->result().chunks.size()){setText("Open firmware and select an object first.");return;}setText(g->analyzer->fxReport((size_t)i));setStatus("FX/DSP cross-reference analysis for selected object.");}
static void showTargets(Obj,SEL,Obj){if(!g)return;if(g->analyzer->result().chunks.empty()){setText("Open firmware first.");return;}setText(g->analyzer->targetReport());setStatus("Pa600 audio / FX / DSP target triage across all parsed objects.");}
static void selectionChanged(Obj,SEL,Obj){if(!g)return;long long i=M<long long>(g->popup,"indexOfSelectedItem");if(i<0||(size_t)i>=g->analyzer->result().chunks.size())return;setText(g->analyzer->chunkReport((size_t)i));const auto&c=g->analyzer->result().chunks[(size_t)i];setStatus(c.typeName+"  "+c.virtualPath+"  "+std::to_string(c.payloadSize)+" bytes");}
static void extractSelected(Obj,SEL,Obj){if(!g)return;long long i=M<long long>(g->popup,"indexOfSelectedItem");if(i<0)return;std::string folder=chooseFolder();if(folder.empty())return;std::string err;if(!g->analyzer->extractChunk((size_t)i,folder,err))alertBox("Extraction failed",err);else setStatus("Selected object extracted successfully.");}
static void extractAll(Obj,SEL,Obj){if(!g||g->analyzer->result().chunks.empty())return;std::string folder=chooseFolder();if(folder.empty())return;std::string err;if(!g->analyzer->extractAll(folder,err))alertBox("Extraction failed",err);else setStatus("All supported objects extracted successfully.");}

static void compareFirmware(Obj,SEL,Obj){
    if(!g||g->analyzer->result().sourcePath.empty()){alertBox("Open the first firmware","Open firmware A before choosing firmware B.");return;}
    Obj p=M<Obj>(C("NSOpenPanel"),"openPanel");M<void>(p,"setCanChooseFiles:",(signed char)1);M<void>(p,"setCanChooseDirectories:",(signed char)0);M<void>(p,"setAllowsMultipleSelection:",(signed char)0);M<void>(p,"setMessage:",str("Select firmware B to compare with the currently open Korg OS."));if(M<long long>(p,"runModal")!=1)return;Obj u=M<Obj>(p,"URL");std::string path=pathString(M<Obj>(u,"path"));krl::Analyzer b;std::string err;if(!b.open(path,err)){alertBox("Could not open comparison firmware",err);return;}setText(krl::FirmwareComparator::compare(g->analyzer->result(),b.result()));setStatus("Compared "+krl::baseName(g->analyzer->result().sourcePath)+" ↔ "+krl::baseName(path));
}

static Class makeDelegateClass(){
    Class base=(Class)objc_getClass("NSObject");Class c=objc_allocateClassPair(base,"KRLAppDelegate",0);if(!c)return (Class)objc_getClass("KRLAppDelegate");
    class_addMethod(c,S("applicationDidFinishLaunching:"),(IMP)appDidFinish,"v@:@");
    class_addMethod(c,S("applicationShouldTerminateAfterLastWindowClosed:"),(IMP)shouldTerminate,"c@:@");
    class_addMethod(c,S("openFirmware:"),(IMP)openFirmware,"v@:@");
    class_addMethod(c,S("showSummary:"),(IMP)showSummary,"v@:@");
    class_addMethod(c,S("showFx:"),(IMP)showFx,"v@:@");
    class_addMethod(c,S("showTargets:"),(IMP)showTargets,"v@:@");
    class_addMethod(c,S("selectionChanged:"),(IMP)selectionChanged,"v@:@");
    class_addMethod(c,S("extractSelected:"),(IMP)extractSelected,"v@:@");
    class_addMethod(c,S("extractAll:"),(IMP)extractAll,"v@:@");
    class_addMethod(c,S("compareFirmware:"),(IMP)compareFirmware,"v@:@");
    objc_registerClassPair(c);return c;
}

int main(int argc,char** argv){
    AppState state;g=&state;Obj pool=M<Obj>(C("NSAutoreleasePool"),"new");Obj app=M<Obj>(C("NSApplication"),"sharedApplication");M<void>(app,"setActivationPolicy:",(long long)0);Class dc=makeDelegateClass();Obj delegate=M<Obj>((Obj)dc,"alloc");delegate=M<Obj>(delegate,"init");M<void>(app,"setDelegate:",delegate);
    if(argc>1) gPendingPath=argv[1];
    M<void>(app,"run");M<void>(pool,"drain");g=nullptr;return 0;
}
