#include "core/Analyzer.h"
#include "core/FirmwareComparator.h"
#include <iostream>
#include <string>
int main(int argc,char**argv){
 if(argc<2){std::cerr<<"KORG RE LAB CLI\nUsage:\n  korg-re-lab-cli <firmware.pkg|firmware.upd|binary> [--extract DIR]\n  korg-re-lab-cli <firmware> --fx [OBJECT_INDEX]\n  korg-re-lab-cli <firmware> --targets\n  korg-re-lab-cli <firmwareA> --compare <firmwareB>\n";return 2;}
 krl::Analyzer a;std::string err;if(!a.open(argv[1],err)){std::cerr<<"Error: "<<err<<"\n";return 1;}
 if(argc>=3&&std::string(argv[2])=="--fx"){size_t i=0;if(argc>=4)i=(size_t)std::stoul(argv[3]);std::cout<<a.fxReport(i);return 0;}
 if(argc>=3&&std::string(argv[2])=="--targets"){std::cout<<a.targetReport();return 0;}
 if(argc>=4&&std::string(argv[2])=="--compare"){krl::Analyzer b;if(!b.open(argv[3],err)){std::cerr<<"Compare open error: "<<err<<"\n";return 1;}std::cout<<krl::FirmwareComparator::compare(a.result(),b.result());return 0;}
 std::cout<<a.summary()<<"\n";if(argc>=4&&std::string(argv[2])=="--extract"){if(!a.extractAll(argv[3],err)){std::cerr<<"Extract error: "<<err<<"\n";return 1;}std::cout<<"Extracted to "<<argv[3]<<"\n";}return 0;
}
