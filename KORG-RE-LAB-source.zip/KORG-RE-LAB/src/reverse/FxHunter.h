#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace krl {
class FxHunter {
public:
    static std::string report(const std::vector<uint8_t>& data,
                              size_t maxStrings = 160,
                              size_t maxReferences = 320);
};
}
