#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace krl {
class ArmDisassembler {
public:
    static std::string disassembleArm(const std::vector<uint8_t>& data, uint32_t base=0, size_t maxInstructions=256);
    static std::string disassembleThumb(const std::vector<uint8_t>& data, uint32_t base=0, size_t maxInstructions=256);
    static std::string functionMap(const std::vector<uint8_t>& data, uint32_t base=0, size_t maxFunctions=512);
};
}
