#include "TargetProfiler.h"
#include "BinaryInspector.h"
#include "FxHunter.h"
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <sstream>

namespace krl {
namespace {

std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

bool containsBytesCaseInsensitive(const std::vector<uint8_t>& data, const std::string& needle) {
    if (needle.empty() || data.size() < needle.size()) return false;
    const std::string n = lower(needle);
    for (size_t i = 0; i + n.size() <= data.size(); ++i) {
        bool match = true;
        for (size_t j = 0; j < n.size(); ++j) {
            const unsigned char c = data[i + j];
            if (static_cast<char>(std::tolower(c)) != n[j]) {
                match = false;
                break;
            }
        }
        if (match) return true;
    }
    return false;
}

void add(TargetEvidence& e, int score, const std::string& reason) {
    e.score += score;
    e.reasons.push_back(reason);
}

std::vector<uint8_t> chunkBytes(const Analysis& analysis, const Chunk& chunk, size_t cap) {
    if (chunk.decoded) return chunk.decodedData;
    if (!chunk.rawPayload.empty()) return chunk.rawPayload;
    if (chunk.sourceBacked && chunk.sourceOffset <= analysis.wholeFile.size() &&
        chunk.sourceSize <= analysis.wholeFile.size() - chunk.sourceOffset) {
        const size_t take = static_cast<size_t>(std::min<uint64_t>(chunk.sourceSize, cap));
        return std::vector<uint8_t>(analysis.wholeFile.begin() + static_cast<size_t>(chunk.sourceOffset),
                                    analysis.wholeFile.begin() + static_cast<size_t>(chunk.sourceOffset) + take);
    }
    return {};
}

std::string confidence(int score) {
    if (score >= 100) return "VERY HIGH";
    if (score >= 60) return "HIGH";
    if (score >= 30) return "MEDIUM";
    if (score > 0) return "LOW";
    return "NONE";
}

} // namespace

TargetEvidence TargetProfiler::score(const Chunk& chunk, const std::vector<uint8_t>& data) {
    TargetEvidence e;
    const std::string path = lower(chunk.virtualPath);
    const std::string type = lower(chunk.typeName);
    const std::string detected = lower(BinaryInspector::identify(data));

    if (path.find("kr_epf_audio_ctrl.ko") != std::string::npos ||
        containsBytesCaseInsensitive(data, "kr_epf_audio_ctrl")) {
        add(e, 120, "Pa600 update-log target: kr_epf_audio_ctrl.ko / kr_epf_audio_ctrl");
    }
    if (path.find("kr_epf_fpga.ko") != std::string::npos || containsBytesCaseInsensitive(data, "kr_epf_fpga"))
        add(e, 45, "Pa600 platform FPGA module evidence");
    if (path.find("kr_epf_i2c_bus.ko") != std::string::npos || containsBytesCaseInsensitive(data, "kr_epf_i2c_bus"))
        add(e, 35, "Pa600 platform I2C bus module evidence");
    if (path.find("kr_epf_andoria_plat.ko") != std::string::npos || containsBytesCaseInsensitive(data, "kr_epf_andoria_plat"))
        add(e, 35, "Pa600 Andoria platform module evidence");
    if (path.find("kr_epf_core.ko") != std::string::npos || containsBytesCaseInsensitive(data, "kr_epf_core"))
        add(e, 35, "Pa600 platform core module evidence");
    if (path.find("snd_tty_midi.ko") != std::string::npos || containsBytesCaseInsensitive(data, "snd_tty_midi"))
        add(e, 25, "MIDI kernel-module evidence");

    if (path.find("/omega_sys/") != std::string::npos || path.find("/emmc/omega_sys") != std::string::npos)
        add(e, 18, "Pa600 omega_sys partition/path evidence");
    if (path.find("/rootfs/") != std::string::npos || path.find("/emmc/rootfs") != std::string::npos)
        add(e, 12, "Pa600 rootfs partition/path evidence");
    if (path.find("andoria") != std::string::npos || containsBytesCaseInsensitive(data, "andoria"))
        add(e, 18, "Andoria platform/kernel fingerprint");

    if (detected.find("elf") != std::string::npos) {
        add(e, 15, "ELF executable/object");
        if (data.size() >= 20 && data[4] == 1 && data[5] == 1 && data[18] == 40 && data[19] == 0)
            add(e, 15, "ELF32 little-endian ARM");
    }
    if (detected.find("u-boot") != std::string::npos)
        add(e, 8, "U-Boot image; possible kernel or firmware payload");
    if (detected.find("device tree") != std::string::npos)
        add(e, 12, "Device tree; useful for audio/DSP hardware routing");
    if (detected.find("ext2/3/4") != std::string::npos)
        add(e, 12, "Linux EXT filesystem image; possible rootfs container");

    static const char* strongTerms[] = {
        "reverb", "chorus", "flanger", "phaser", "mastering limiter", "multitap",
        "pitch shifter", "rotary speaker", "effect", "dsp"
    };
    static const char* audioTerms[] = {
        "audio", "alsa", "pcm", "mixer", "codec", "mcasp", "remoteproc", "firmware"
    };
    for (const char* term : strongTerms) {
        if (path.find(term) != std::string::npos || containsBytesCaseInsensitive(data, term)) {
            add(e, 12, std::string("FX/DSP term: ") + term);
        }
    }
    for (const char* term : audioTerms) {
        if (path.find(term) != std::string::npos || containsBytesCaseInsensitive(data, term)) {
            add(e, 6, std::string("audio/platform term: ") + term);
        }
    }

    // The hunter output itself is evidence only when it reports an actual vocabulary hit.
    if (!data.empty()) {
        const std::string fx = FxHunter::report(data);
        if (fx.find("Exact FX/DSP vocabulary hits: 0") == std::string::npos &&
            fx.find("(no Pa600 FX/DSP vocabulary strings found)") == std::string::npos) {
            add(e, 25, "FX/DSP Hunter found effect vocabulary in this object");
        }
        if (fx.find("Code xrefs found: 0") == std::string::npos &&
            fx.find("ARM/Thumb code xrefs") != std::string::npos) {
            add(e, 35, "FX/DSP Hunter found ARM/Thumb code-to-string xref(s)");
        }
    }

    if (type.find("encrypted") != std::string::npos || chunk.encrypted)
        add(e, -5, "encrypted payload limits direct static analysis");
    return e;
}

std::string TargetProfiler::report(const Analysis& analysis) {
    struct Row {
        size_t index = 0;
        TargetEvidence evidence;
        std::string type;
        std::string path;
        uint64_t size = 0;
    };

    std::vector<Row> rows;
    rows.reserve(analysis.chunks.size());
    constexpr size_t kScanCap = 64u * 1024u * 1024u;
    for (size_t i = 0; i < analysis.chunks.size(); ++i) {
        const Chunk& c = analysis.chunks[i];
        std::vector<uint8_t> bytes = chunkBytes(analysis, c, kScanCap);
        TargetEvidence e = score(c, bytes);
        rows.push_back({i, std::move(e), c.typeName, c.virtualPath, c.sourceBacked ? c.sourceSize : c.payloadSize});
    }

    std::stable_sort(rows.begin(), rows.end(), [](const Row& a, const Row& b) {
        return a.evidence.score > b.evidence.score;
    });

    std::ostringstream out;
    out << "Pa600 Target Profiler\n"
        << "Evidence-weighted triage for audio / FX / DSP reverse engineering.\n"
        << "The score prioritizes inspection; it does NOT prove that musical DSP math lives in a target.\n\n";

    size_t shown = 0;
    for (const Row& row : rows) {
        if (row.evidence.score <= 0) continue;
        out << "#" << row.index << "  score=" << row.evidence.score
            << "  confidence=" << confidence(row.evidence.score)
            << "  " << row.type << "  " << (row.path.empty() ? "(no path)" : row.path)
            << "  [" << row.size << " bytes]\n";
        for (const std::string& reason : row.evidence.reasons)
            out << "    + " << reason << "\n";
        out << "\n";
        ++shown;
    }
    if (shown == 0)
        out << "No Pa600-specific audio/FX/DSP target evidence was found in the currently parsed objects.\n";
    return out.str();
}

} // namespace krl
