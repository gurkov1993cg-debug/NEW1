#include "BinaryInspector.h"
#include "ArmDisassembler.h"
#include "core/Utils.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstring>
#include <iomanip>
#include <sstream>
#include <zlib.h>

namespace krl {
namespace {

uint16_t rd16(const uint8_t* p, bool littleEndian) {
    return littleEndian ? le16(p) : uint16_t(p[1]) | (uint16_t(p[0]) << 8);
}

uint32_t rd32(const uint8_t* p, bool littleEndian) {
    return littleEndian ? le32(p) : be32(p);
}

uint64_t rd64(const uint8_t* p, bool littleEndian) {
    if (littleEndian) {
        return le64(p);
    }
    uint64_t v = 0;
    for (int i = 0; i < 8; ++i) {
        v = (v << 8) | p[i];
    }
    return v;
}

const char* compressionName(unsigned value) {
    switch (value) {
        case 0: return "none";
        case 1: return "gzip";
        case 2: return "bzip2";
        case 3: return "lzma";
        case 4: return "lzo";
        case 5: return "lz4";
        case 6: return "zstd";
        default: return "unknown";
    }
}

bool gunzip(const uint8_t* input, size_t inputSize, std::vector<uint8_t>& output) {
    output.clear();
    z_stream z{};
    if (inflateInit2(&z, 16 + MAX_WBITS) != Z_OK) {
        return false;
    }

    z.next_in = const_cast<Bytef*>(input);
    z.avail_in = static_cast<uInt>(std::min<size_t>(inputSize, 0xffffffffu));

    constexpr size_t kMaximumDecodedSize = 256u * 1024u * 1024u;
    uint8_t buffer[65536];
    int rc = Z_OK;

    while (rc == Z_OK) {
        z.next_out = buffer;
        z.avail_out = sizeof(buffer);
        rc = inflate(&z, Z_NO_FLUSH);
        const size_t produced = sizeof(buffer) - z.avail_out;
        if (output.size() + produced > kMaximumDecodedSize) {
            inflateEnd(&z);
            output.clear();
            return false;
        }
        output.insert(output.end(), buffer, buffer + produced);
        if (z.avail_in == 0 && rc != Z_STREAM_END) {
            break;
        }
    }

    inflateEnd(&z);
    return rc == Z_STREAM_END;
}

bool extractArmCodeFromElf(const std::vector<uint8_t>& data,
                           std::vector<uint8_t>& code,
                           uint32_t& baseAddress) {
    if (data.size() < 52 || std::memcmp(data.data(), "\x7f" "ELF", 4) != 0 ||
        data[4] != 1 || data[5] != 1 || le16(&data[18]) != 40) {
        return false;
    }

    const uint32_t entry = le32(&data[24]);
    const uint32_t programHeaderOffset = le32(&data[28]);
    const uint16_t programHeaderSize = le16(&data[42]);
    const uint16_t programHeaderCount = le16(&data[44]);
    if (programHeaderSize == 0 || programHeaderOffset > data.size()) {
        return false;
    }

    int best = -1;
    uint32_t bestOffset = 0;
    uint32_t bestVirtualAddress = 0;
    uint32_t bestFileSize = 0;

    for (uint16_t i = 0; i < programHeaderCount; ++i) {
        const uint64_t pos = uint64_t(programHeaderOffset) + uint64_t(i) * programHeaderSize;
        if (pos + 32 > data.size()) {
            break;
        }

        const uint8_t* p = &data[static_cast<size_t>(pos)];
        const uint32_t type = le32(p);
        const uint32_t fileOffset = le32(p + 4);
        const uint32_t virtualAddress = le32(p + 8);
        const uint32_t fileSize = le32(p + 16);
        const uint32_t memorySize = le32(p + 20);
        const uint32_t flags = le32(p + 24);

        if (type != 1 || fileSize == 0 || uint64_t(fileOffset) + fileSize > data.size()) {
            continue;
        }

        const bool containsEntry = entry >= virtualAddress &&
            uint64_t(entry) < uint64_t(virtualAddress) + memorySize;
        const bool executable = (flags & 1u) != 0;

        if (containsEntry) {
            best = 2;
            bestOffset = fileOffset;
            bestVirtualAddress = virtualAddress;
            bestFileSize = fileSize;
            break;
        }
        if (executable && best < 1) {
            best = 1;
            bestOffset = fileOffset;
            bestVirtualAddress = virtualAddress;
            bestFileSize = fileSize;
        }
    }

    if (best < 0) {
        return false;
    }

    code.assign(data.begin() + bestOffset, data.begin() + bestOffset + bestFileSize);
    baseAddress = bestVirtualAddress;
    return true;
}

} // namespace

std::string BinaryInspector::identify(const std::vector<uint8_t>& data) {
    if (data.size() >= 4 && data[0] == 0x7f && data[1] == 'E' && data[2] == 'L' && data[3] == 'F') {
        return "ELF executable/object";
    }
    if (data.size() >= 4 && be32(data.data()) == 0x27051956) {
        return "U-Boot legacy uImage";
    }
    if (data.size() >= 3 && data[0] == 0x1f && data[1] == 0x8b && data[2] == 0x08) {
        return "gzip stream";
    }
    if (data.size() >= 6 && std::memcmp(data.data(), "\xfd" "7zXZ\0", 6) == 0) {
        return "XZ stream";
    }
    if (data.size() >= 4 && std::memcmp(data.data(), "hsqs", 4) == 0) {
        return "SquashFS filesystem";
    }
    if (data.size() >= 4 && be32(data.data()) == 0xD00DFEED) {
        return "Flattened Device Tree (DTB)";
    }
    if (data.size() >= 262 && std::memcmp(&data[257], "ustar", 5) == 0) {
        return "TAR archive";
    }
    if (data.size() >= 1082 && le16(&data[1080]) == 0xEF53) {
        return "EXT2/3/4 filesystem image";
    }
    return "Raw/unknown binary";
}

std::string BinaryInspector::uImageReport(const std::vector<uint8_t>& data) {
    if (data.size() < 64 || be32(data.data()) != 0x27051956) {
        return {};
    }

    const uint32_t storedHeaderCrc = be32(&data[4]);
    const uint32_t timestamp = be32(&data[8]);
    const uint32_t payloadSize = be32(&data[12]);
    const uint32_t loadAddress = be32(&data[16]);
    const uint32_t entryPoint = be32(&data[20]);
    const uint32_t storedDataCrc = be32(&data[24]);
    const unsigned os = data[28];
    const unsigned arch = data[29];
    const unsigned type = data[30];
    const unsigned compression = data[31];

    char name[33] = {0};
    std::memcpy(name, &data[32], 32);

    uint8_t header[64];
    std::memcpy(header, data.data(), sizeof(header));
    std::memset(header + 4, 0, 4);
    uint32_t calculatedHeaderCrc = static_cast<uint32_t>(crc32(0L, Z_NULL, 0));
    calculatedHeaderCrc = static_cast<uint32_t>(crc32(calculatedHeaderCrc, header, sizeof(header)));

    const bool payloadPresent = uint64_t(64) + payloadSize <= data.size();
    uint32_t calculatedDataCrc = 0;
    if (payloadPresent) {
        calculatedDataCrc = static_cast<uint32_t>(crc32(0L, Z_NULL, 0));
        calculatedDataCrc = static_cast<uint32_t>(
            crc32(calculatedDataCrc, &data[64], payloadSize));
    }

    std::ostringstream out;
    out << "U-Boot legacy uImage\n"
        << "Magic: 0x27051956\n"
        << "Header CRC: 0x" << std::hex << std::uppercase << storedHeaderCrc
        << "  calculated 0x" << calculatedHeaderCrc
        << "  [" << (calculatedHeaderCrc == storedHeaderCrc ? "VALID" : "MISMATCH") << "]\n"
        << "Timestamp: 0x" << timestamp << "\n"
        << "Data size: " << std::dec << payloadSize << "\n"
        << "Load address: 0x" << std::hex << loadAddress << "\n"
        << "Entry point: 0x" << entryPoint << "\n"
        << "Data CRC: 0x" << storedDataCrc;

    if (payloadPresent) {
        out << "  calculated 0x" << calculatedDataCrc
            << "  [" << (calculatedDataCrc == storedDataCrc ? "VALID" : "MISMATCH") << "]";
    } else {
        out << "  [payload truncated]";
    }

    out << "\nOS: " << std::dec << os
        << "  Arch: " << arch << (arch == 2 ? " (ARM)" : "")
        << "  Type: " << type
        << "  Compression: " << compression << " (" << compressionName(compression) << ")\n"
        << "Name: " << name << "\n";
    return out.str();
}

std::string BinaryInspector::elfReport(const std::vector<uint8_t>& data) {
    if (data.size() < 52 || std::memcmp(data.data(), "\x7f" "ELF", 4) != 0) {
        return {};
    }

    const bool is64 = data[4] == 2;
    const bool littleEndian = data[5] == 1;
    std::ostringstream out;
    out << "ELF " << (is64 ? "64" : "32") << "-bit "
        << (littleEndian ? "little" : "big") << "-endian\n";

    const uint16_t type = rd16(&data[16], littleEndian);
    const uint16_t machine = rd16(&data[18], littleEndian);
    out << "Type: " << type << "  Machine: " << machine;
    if (machine == 40) out << " (ARM)";
    else if (machine == 183) out << " (AArch64)";
    else if (machine == 3) out << " (x86)";
    else if (machine == 62) out << " (x86-64)";
    out << "\n";

    if (!is64) {
        const uint32_t entry = rd32(&data[24], littleEndian);
        const uint32_t ph = rd32(&data[28], littleEndian);
        const uint32_t sh = rd32(&data[32], littleEndian);
        const uint16_t phn = rd16(&data[44], littleEndian);
        const uint16_t shn = rd16(&data[48], littleEndian);
        out << "Entry: 0x" << std::hex << std::uppercase << entry
            << "\nProgram headers: offset 0x" << ph << " count " << std::dec << phn
            << "\nSection headers: offset 0x" << std::hex << sh << " count " << std::dec << shn << "\n";
    } else if (data.size() >= 64) {
        const uint64_t entry = rd64(&data[24], littleEndian);
        const uint64_t ph = rd64(&data[32], littleEndian);
        const uint64_t sh = rd64(&data[40], littleEndian);
        const uint16_t phn = rd16(&data[56], littleEndian);
        const uint16_t shn = rd16(&data[60], littleEndian);
        out << "Entry: 0x" << std::hex << std::uppercase << entry
            << "\nProgram headers: offset 0x" << ph << " count " << std::dec << phn
            << "\nSection headers: offset 0x" << std::hex << sh << " count " << std::dec << shn << "\n";
    }
    return out.str();
}

std::string BinaryInspector::elfSymbolReport(const std::vector<uint8_t>& data, size_t maxHits) {
    if (data.size() < 52 || std::memcmp(data.data(), "\x7f" "ELF", 4) != 0) {
        return {};
    }

    const bool is64 = data[4] == 2;
    const bool littleEndian = data[5] == 1;
    if ((data[4] != 1 && data[4] != 2) || (data[5] != 1 && data[5] != 2)) {
        return {};
    }
    const size_t headerSize = is64 ? 64 : 52;
    if (data.size() < headerSize) {
        return {};
    }

    const uint64_t sectionOffset = is64 ? rd64(&data[40], littleEndian) : rd32(&data[32], littleEndian);
    const uint16_t sectionEntrySize = rd16(&data[is64 ? 58 : 46], littleEndian);
    const uint16_t sectionCount = rd16(&data[is64 ? 60 : 48], littleEndian);
    if (sectionEntrySize == 0 || sectionCount == 0 || sectionOffset > data.size() ||
        uint64_t(sectionEntrySize) * sectionCount > data.size() - sectionOffset) {
        return "ELF interesting symbols\n(no valid section table)\n";
    }

    struct Section {
        uint32_t type = 0;
        uint32_t link = 0;
        uint64_t offset = 0;
        uint64_t size = 0;
        uint64_t entrySize = 0;
    };

    std::vector<Section> sections(sectionCount);
    for (uint16_t i = 0; i < sectionCount; ++i) {
        const uint8_t* p = &data[static_cast<size_t>(sectionOffset + uint64_t(i) * sectionEntrySize)];
        Section section;
        section.type = rd32(p + 4, littleEndian);
        if (is64) {
            section.offset = rd64(p + 24, littleEndian);
            section.size = rd64(p + 32, littleEndian);
            section.link = rd32(p + 40, littleEndian);
            section.entrySize = rd64(p + 56, littleEndian);
        } else {
            section.offset = rd32(p + 16, littleEndian);
            section.size = rd32(p + 20, littleEndian);
            section.link = rd32(p + 24, littleEndian);
            section.entrySize = rd32(p + 36, littleEndian);
        }
        sections[i] = section;
    }

    static const char* keywords[] = {
        "fx", "effect", "reverb", "delay", "chorus", "flanger", "phaser",
        "compress", "limiter", "eq", "filter", "audio", "alsa", "mixer",
        "dsp", "sound", "pcm", "codec", "voice", "osc", "style"
    };

    std::ostringstream out;
    out << "ELF interesting symbols\n";
    size_t hits = 0;
    size_t totalSymbols = 0;

    for (size_t sectionIndex = 0; sectionIndex < sections.size() && hits < maxHits; ++sectionIndex) {
        const Section& section = sections[sectionIndex];
        if (section.type != 2 && section.type != 11) {
            continue;
        }
        if (section.entrySize == 0 || section.link >= sections.size() ||
            section.offset > data.size() || section.size > data.size() - section.offset) {
            continue;
        }

        const Section& strings = sections[section.link];
        if (strings.offset > data.size() || strings.size > data.size() - strings.offset) {
            continue;
        }

        for (uint64_t pos = 0; pos + section.entrySize <= section.size && hits < maxHits;
             pos += section.entrySize) {
            const uint8_t* symbol = &data[static_cast<size_t>(section.offset + pos)];
            const uint32_t nameOffset = rd32(symbol, littleEndian);
            ++totalSymbols;
            if (nameOffset >= strings.size) {
                continue;
            }

            const size_t nameStart = static_cast<size_t>(strings.offset + nameOffset);
            size_t nameEnd = nameStart;
            while (nameEnd < strings.offset + strings.size && data[nameEnd] != 0) {
                ++nameEnd;
            }
            if (nameEnd >= strings.offset + strings.size || nameEnd == nameStart) {
                continue;
            }

            std::string name(reinterpret_cast<const char*>(&data[nameStart]), nameEnd - nameStart);
            std::string lower = name;
            std::transform(lower.begin(), lower.end(), lower.begin(),
                           [](unsigned char c) { return char(std::tolower(c)); });

            bool interesting = false;
            for (const char* keyword : keywords) {
                if (lower.find(keyword) != std::string::npos) {
                    interesting = true;
                    break;
                }
            }
            if (!interesting) {
                continue;
            }

            const uint64_t value = is64 ? rd64(symbol + 8, littleEndian) : rd32(symbol + 4, littleEndian);
            const uint64_t size = is64 ? rd64(symbol + 16, littleEndian) : rd32(symbol + 8, littleEndian);
            out << "0x" << std::hex << std::uppercase << value << std::dec
                << "  size=" << size << "  " << name << "\n";
            ++hits;
        }
    }

    if (totalSymbols == 0) {
        out << "(no SYMTAB/DYNSYM entries)\n";
    } else if (hits == 0) {
        out << "(symbol tables present; no audio/FX keyword matches among "
            << totalSymbols << " symbols)\n";
    }
    if (hits >= maxHits) {
        out << "... hit limit reached ...\n";
    }
    return out.str();
}

std::string BinaryInspector::dtbReport(const std::vector<uint8_t>& data, size_t maxNodes) {
    if (data.size() < 40 || be32(data.data()) != 0xD00DFEED) {
        return {};
    }

    const uint32_t totalSize = be32(&data[4]);
    const uint32_t structOffset = be32(&data[8]);
    const uint32_t stringsOffset = be32(&data[12]);
    const uint32_t stringsSize = be32(&data[32]);
    const uint32_t structSize = be32(&data[36]);
    if (totalSize < 40 || totalSize > data.size() || structOffset >= totalSize ||
        stringsOffset >= totalSize || uint64_t(stringsOffset) + stringsSize > totalSize ||
        uint64_t(structOffset) + structSize > totalSize) {
        return "DTB header is malformed or truncated.\n";
    }

    auto stringAt = [&](uint32_t offset) -> std::string {
        if (offset >= stringsSize) {
            return {};
        }
        const size_t start = stringsOffset + offset;
        size_t end = start;
        while (end < stringsOffset + stringsSize && data[end] != 0) {
            ++end;
        }
        if (end >= stringsOffset + stringsSize) {
            return {};
        }
        return std::string(reinterpret_cast<const char*>(&data[start]), end - start);
    };

    auto textValue = [](const uint8_t* p, size_t n) -> std::string {
        std::string result;
        for (size_t i = 0; i < n; ++i) {
            const unsigned c = p[i];
            if (c == 0) {
                if (!result.empty() && result.back() != ',') {
                    result += ',';
                }
            } else if (c >= 32 && c <= 126) {
                result += char(c);
            } else {
                return {};
            }
        }
        while (!result.empty() && result.back() == ',') {
            result.pop_back();
        }
        return result;
    };

    struct Node {
        std::string path;
        std::string compatible;
        std::string status;
        std::string reg;
    };

    std::vector<Node> matchingNodes;
    std::vector<std::string> stack;
    Node current;

    auto maybeStoreCurrent = [&]() {
        if (current.path.empty()) {
            return;
        }
        std::string searchable = current.path + " " + current.compatible;
        std::transform(searchable.begin(), searchable.end(), searchable.begin(),
                       [](unsigned char c) { return char(std::tolower(c)); });
        static const char* terms[] = {
            "audio", "sound", "dsp", "remoteproc", "mailbox", "mcasp", "mcbsp",
            "i2s", "codec", "i2c", "spi", "mmc", "gpio", "usb", "serial",
            "uart", "pwm", "clock", "dma"
        };
        bool match = false;
        for (const char* term : terms) {
            if (searchable.find(term) != std::string::npos) {
                match = true;
                break;
            }
        }
        if (match && matchingNodes.size() < maxNodes) {
            matchingNodes.push_back(current);
        }
    };

    size_t pos = structOffset;
    const size_t end = structOffset + structSize;
    size_t tokenCount = 0;
    while (pos + 4 <= end) {
        const uint32_t token = be32(&data[pos]);
        pos += 4;

        if (token == 1) { // FDT_BEGIN_NODE
            maybeStoreCurrent();
            size_t nameEnd = pos;
            while (nameEnd < end && data[nameEnd] != 0) {
                ++nameEnd;
            }
            if (nameEnd >= end) {
                break;
            }
            std::string name(reinterpret_cast<const char*>(&data[pos]), nameEnd - pos);
            pos = (nameEnd + 1 + 3) & ~size_t(3);
            stack.push_back(name);

            std::ostringstream path;
            for (size_t i = 0; i < stack.size(); ++i) {
                if (i == 0 && stack[i].empty()) {
                    path << '/';
                    continue;
                }
                if (path.tellp() > 1) {
                    path << '/';
                }
                path << stack[i];
            }
            current = Node{};
            current.path = path.str();
        } else if (token == 2) { // FDT_END_NODE
            maybeStoreCurrent();
            current = Node{};
            if (!stack.empty()) {
                stack.pop_back();
            }
        } else if (token == 3) { // FDT_PROP
            if (pos + 8 > end) {
                break;
            }
            const uint32_t length = be32(&data[pos]);
            const uint32_t nameOffset = be32(&data[pos + 4]);
            pos += 8;
            if (uint64_t(pos) + length > end) {
                break;
            }
            const std::string propertyName = stringAt(nameOffset);
            const uint8_t* value = &data[pos];
            if (propertyName == "compatible") {
                current.compatible = textValue(value, length);
            } else if (propertyName == "status") {
                current.status = textValue(value, length);
            } else if (propertyName == "reg" && length >= 4) {
                std::ostringstream reg;
                reg << "0x" << std::hex << std::uppercase << be32(value);
                current.reg = reg.str();
            }
            pos = (pos + length + 3) & ~size_t(3);
        } else if (token == 4) { // FDT_NOP
            // No payload.
        } else if (token == 9) { // FDT_END
            maybeStoreCurrent();
            break;
        } else {
            break;
        }

        ++tokenCount;
        if (tokenCount > 1000000) {
            break;
        }
    }

    std::ostringstream out;
    out << "Flattened Device Tree\n"
        << "Total size: " << totalSize << " bytes  Version: " << be32(&data[20])
        << "  Struct: 0x" << std::hex << std::uppercase << structOffset << "+0x" << structSize
        << "  Strings: 0x" << stringsOffset << "+0x" << stringsSize << std::dec
        << "\n\nHardware-relevant nodes\n";

    if (matchingNodes.empty()) {
        out << "(no matching hardware nodes)\n";
    } else {
        for (const Node& node : matchingNodes) {
            out << node.path;
            if (!node.reg.empty()) out << "  reg=" << node.reg;
            if (!node.compatible.empty()) out << "  compatible=" << node.compatible;
            if (!node.status.empty()) out << "  status=" << node.status;
            out << "\n";
        }
    }
    return out.str();
}

std::string BinaryInspector::extFilesystemReport(const std::vector<uint8_t>& data) {
    constexpr size_t kSuper = 1024;
    if (data.size() < kSuper + 236 || le16(&data[kSuper + 56]) != 0xEF53) {
        return {};
    }

    const uint8_t* sb = &data[kSuper];
    const uint32_t inodes = le32(sb + 0);
    const uint32_t blocks = le32(sb + 4);
    const uint32_t freeBlocks = le32(sb + 12);
    const uint32_t freeInodes = le32(sb + 16);
    const uint32_t logBlock = le32(sb + 24);
    const uint32_t blocksPerGroup = le32(sb + 32);
    const uint32_t inodesPerGroup = le32(sb + 40);
    const uint16_t state = le16(sb + 58);
    const uint16_t errors = le16(sb + 60);
    const uint32_t revision = le32(sb + 76);
    const uint16_t inodeSize = le16(sb + 88);
    const uint32_t compat = le32(sb + 92);
    const uint32_t incompat = le32(sb + 96);
    const uint32_t roCompat = le32(sb + 100);

    uint64_t blockSize = 0;
    if (logBlock <= 6) blockSize = 1024ull << logBlock;

    auto cleanField = [](const uint8_t* p, size_t n) {
        size_t end = 0;
        while (end < n && p[end] != 0) ++end;
        std::string text(reinterpret_cast<const char*>(p), end);
        for (char& c : text) {
            if (static_cast<unsigned char>(c) < 32 || static_cast<unsigned char>(c) > 126) c = '?';
        }
        return text;
    };

    const std::string label = cleanField(sb + 120, 16);
    const std::string lastMounted = cleanField(sb + 136, 64);
    const bool hasJournal = (compat & 0x00000004u) != 0;
    const bool hasExtents = (incompat & 0x00000040u) != 0;
    const char* family = hasExtents ? "EXT4-family" : (hasJournal ? "EXT3-family" : "EXT2-family");

    std::ostringstream out;
    out << "Linux EXT filesystem superblock\n"
        << "Magic: 0xEF53 [VALID]\n"
        << "Likely family: " << family << "\n"
        << "Volume label: " << (label.empty() ? "(none)" : label) << "\n"
        << "Last mounted: " << (lastMounted.empty() ? "(none)" : lastMounted) << "\n"
        << "Inodes: " << inodes << "  Free inodes: " << freeInodes << "\n"
        << "Blocks: " << blocks << "  Free blocks: " << freeBlocks << "\n"
        << "Block size: " << blockSize << " bytes  Blocks/group: " << blocksPerGroup
        << "  Inodes/group: " << inodesPerGroup << "\n"
        << "Revision: " << revision << "  Inode size: " << inodeSize << "\n"
        << "State: 0x" << std::hex << std::uppercase << state
        << "  Errors policy: 0x" << errors << "\n"
        << "Features compat=0x" << compat << " incompat=0x" << incompat
        << " ro_compat=0x" << roCompat << std::dec << "\n";
    if (hasJournal) out << "Journal feature: present\n";
    if (hasExtents) out << "Extents feature: present\n";
    return out.str();
}

std::string BinaryInspector::firmwareFingerprintReport(const std::vector<uint8_t>& data, size_t maxHits) {
    std::ostringstream out;
    out << "Firmware fingerprints\n";

    static const char* terms[] = {
        "Linux version ", "PREEMPT", "workhorse", "KORG-SW", "arvon", "OMAP", "omap",
        "McASP", "mcasp", "ALSA", "snd_", "codec", "DSP", "remoteproc", "firmware",
        "effect", "reverb", "chorus", "delay", "mixer", "andoria", "omega_sys",
        "kr_epf_audio_ctrl", "kr_epf_fpga", "kr_epf_i2c_bus", "kr_epf_andoria_plat",
        "kr_epf_core", "snd_tty_midi", "mmcblk0p7"
    };

    size_t hits = 0;
    size_t start = 0;
    std::string current;

    auto emitIfInteresting = [&]() {
        if (current.size() < 6) {
            return;
        }
        bool interesting = false;
        for (const char* term : terms) {
            if (current.find(term) != std::string::npos) {
                interesting = true;
                break;
            }
        }
        if (interesting && hits < maxHits) {
            out << "0x" << std::hex << std::uppercase << start << "  " << current << "\n";
            ++hits;
        }
    };

    for (size_t i = 0; i <= data.size() && hits < maxHits; ++i) {
        const bool printable = i < data.size() &&
            (data[i] == 9 || data[i] == 32 || (data[i] >= 33 && data[i] <= 126));
        if (printable) {
            if (current.empty()) {
                start = i;
            }
            if (current.size() < 4096) {
                current.push_back(char(data[i]));
            }
        } else {
            emitIfInteresting();
            current.clear();
        }
    }

    if (hits == 0) {
        out << "(no built-in firmware fingerprints found)\n";
    }
    if (hits >= maxHits) {
        out << "... hit limit reached ...\n";
    }
    return out.str();
}

std::string BinaryInspector::signaturesReport(const std::vector<uint8_t>& data, size_t maxHits) {
    std::ostringstream out;
    out << "Embedded signatures\n";
    size_t hits = 0;

    for (size_t i = 0; i < data.size() && hits < maxHits; ++i) {
        const char* name = nullptr;
        if (i + 4 <= data.size() && data[i] == 0x7f && data[i + 1] == 'E' &&
            data[i + 2] == 'L' && data[i + 3] == 'F') {
            name = "ELF";
        } else if (i + 4 <= data.size() && data[i] == 0x27 && data[i + 1] == 0x05 &&
                   data[i + 2] == 0x19 && data[i + 3] == 0x56) {
            name = "uImage";
        } else if (i + 3 <= data.size() && data[i] == 0x1f && data[i + 1] == 0x8b &&
                   data[i + 2] == 0x08) {
            name = "gzip";
        } else if (i + 6 <= data.size() && data[i] == 0xfd &&
                   std::memcmp(&data[i], "\xfd" "7zXZ\0", 6) == 0) {
            name = "XZ";
        } else if (i + 4 <= data.size() && std::memcmp(&data[i], "hsqs", 4) == 0) {
            name = "SquashFS";
        } else if (i + 4 <= data.size() && data[i] == 0xd0 && data[i + 1] == 0x0d &&
                   data[i + 2] == 0xfe && data[i + 3] == 0xed) {
            name = "DTB";
        } else if (i + 4 <= data.size() && data[i] == 'P' && data[i + 1] == 'K' &&
                   data[i + 2] == 3 && data[i + 3] == 4) {
            name = "PK ZIP";
        }

        if (name != nullptr) {
            out << "0x" << std::hex << std::uppercase << i << "  " << name << "\n";
            ++hits;
        }
    }

    if (hits == 0) {
        out << "(none of the built-in signatures found)\n";
    }
    if (hits >= maxHits) {
        out << "... hit limit reached ...\n";
    }
    return out.str();
}

std::string BinaryInspector::entropyReport(const std::vector<uint8_t>& data,
                                           size_t window,
                                           size_t maxWindows) {
    if (data.empty()) {
        return {};
    }

    window = std::max<size_t>(4096, window);
    struct EntropyWindow {
        size_t offset = 0;
        size_t size = 0;
        double entropy = 0.0;
    };

    std::vector<EntropyWindow> windows;
    for (size_t offset = 0; offset < data.size(); offset += window) {
        const size_t count = std::min(window, data.size() - offset);
        size_t frequencies[256] = {0};
        for (size_t i = 0; i < count; ++i) {
            ++frequencies[data[offset + i]];
        }

        double entropy = 0.0;
        for (size_t frequency : frequencies) {
            if (frequency == 0) {
                continue;
            }
            const double probability = double(frequency) / double(count);
            entropy -= probability * std::log2(probability);
        }
        windows.push_back({offset, count, entropy});
    }

    double sum = 0.0;
    double minimum = 9.0;
    double maximum = -1.0;
    for (const EntropyWindow& entry : windows) {
        sum += entry.entropy;
        minimum = std::min(minimum, entry.entropy);
        maximum = std::max(maximum, entry.entropy);
    }

    std::vector<EntropyWindow> highest = windows;
    std::sort(highest.begin(), highest.end(),
              [](const EntropyWindow& a, const EntropyWindow& b) {
                  return a.entropy > b.entropy;
              });
    if (highest.size() > maxWindows) {
        highest.resize(maxWindows);
    }

    std::ostringstream out;
    out << "Entropy map (Shannon, " << window << "-byte windows)\n"
        << "Average: " << std::fixed << std::setprecision(4) << (sum / windows.size())
        << " bits/byte  Min: " << minimum << "  Max: " << maximum
        << "\nHighest-entropy windows\n";
    for (const EntropyWindow& entry : highest) {
        out << "0x" << std::hex << std::uppercase << entry.offset
            << "  0x" << (entry.offset + entry.size) << std::dec
            << "  " << std::fixed << std::setprecision(4) << entry.entropy << "\n";
    }
    return out.str();
}

std::string BinaryInspector::disassemblyPreview(const std::vector<uint8_t>& data) {
    if (data.empty()) {
        return {};
    }

    std::vector<uint8_t> code;
    uint32_t baseAddress = 0;

    if (data.size() >= 64 && be32(data.data()) == 0x27051956) {
        const uint32_t payloadSize = be32(&data[12]);
        const uint32_t entryPoint = be32(&data[20]);
        const unsigned compression = data[31];
        if (uint64_t(64) + payloadSize > data.size()) {
            return "uImage payload is truncated.\n";
        }

        if (compression == 0) {
            code.assign(data.begin() + 64, data.begin() + 64 + payloadSize);
        } else if (compression == 1) {
            if (!gunzip(&data[64], payloadSize, code)) {
                return "uImage gzip payload could not be decompressed.\n";
            }
        } else {
            std::ostringstream out;
            out << "uImage compression " << compression << " ("
                << compressionName(compression)
                << ") is not decoded by the built-in preview.\n";
            return out.str();
        }
        baseAddress = entryPoint;
    } else if (!extractArmCodeFromElf(data, code, baseAddress)) {
        code = data;
        baseAddress = 0;
    }

    return ArmDisassembler::functionMap(code, baseAddress, 512) + "\n" +
           ArmDisassembler::disassembleArm(code, baseAddress, 220) + "\n" +
           ArmDisassembler::disassembleThumb(code, baseAddress, 180);
}

} // namespace krl
