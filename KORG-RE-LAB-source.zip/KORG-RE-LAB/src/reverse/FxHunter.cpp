#include "FxHunter.h"
#include "core/Utils.h"

#include <algorithm>
#include <cctype>
#include <cstring>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <zlib.h>

namespace krl { namespace {

struct Segment {
    uint32_t fileOffset = 0;
    uint32_t virtualAddress = 0;
    uint32_t fileSize = 0;
    uint32_t memorySize = 0;
    uint32_t flags = 0;
};

struct StringHit {
    size_t fileOffset = 0;
    uint32_t virtualAddress = 0;
    bool hasVirtualAddress = false;
    std::string text;
};

struct RefHit {
    uint32_t instructionAddress = 0;
    uint32_t functionAddress = 0;
    std::string mode;
    std::string mechanism;
};

static std::string lower(std::string s) {
    for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

static bool containsFxTerm(const std::string& text) {
    const std::string s = lower(text);
    static const char* terms[] = {
        "stereo chorus", "black chorus", "multitap", "mastering limiter",
        "compressor", "limiter", "exciter", "overdrive", "distortion",
        "amp simulation", "amp sim", "reverb", "chorus", "flanger", "phaser",
        "delay", "echo", "ensemble", "rotary", "tremolo", "vibrato",
        "pitch shifter", "pitch shift", "wah", "talking modulator",
        "early reflection", "room", "hall", "plate", "dynamic", "effect",
        "insert fx", "master fx", "wet/dry", "lfo frequency", "pre delay",
        "feedback", "eq trim", "side peq", "remS", "dsp"
    };
    for (const char* term : terms) {
        if (s.find(lower(term)) != std::string::npos) return true;
    }
    return false;
}

static bool parseArmElf32(const std::vector<uint8_t>& d,
                          std::vector<Segment>& segments,
                          uint32_t& entry) {
    segments.clear(); entry = 0;
    if (d.size() < 52 || std::memcmp(d.data(), "\x7f" "ELF", 4) != 0) return false;
    if (d[4] != 1 || d[5] != 1 || le16(&d[18]) != 40) return false;
    entry = le32(&d[24]);
    const uint32_t phoff = le32(&d[28]);
    const uint16_t phentsize = le16(&d[42]);
    const uint16_t phnum = le16(&d[44]);
    if (phentsize < 32 || phoff > d.size()) return false;
    for (uint16_t i = 0; i < phnum; ++i) {
        const uint64_t p = uint64_t(phoff) + uint64_t(i) * phentsize;
        if (p + 32 > d.size()) break;
        const uint8_t* q = &d[size_t(p)];
        if (le32(q) != 1) continue;
        Segment s;
        s.fileOffset = le32(q + 4);
        s.virtualAddress = le32(q + 8);
        s.fileSize = le32(q + 16);
        s.memorySize = le32(q + 20);
        s.flags = le32(q + 24);
        if (uint64_t(s.fileOffset) + s.fileSize <= d.size()) segments.push_back(s);
    }
    return !segments.empty();
}

static bool fileToVirtual(size_t off, const std::vector<Segment>& segs, uint32_t& va) {
    for (const Segment& s : segs) {
        if (off >= s.fileOffset && off < uint64_t(s.fileOffset) + s.fileSize) {
            const uint64_t v = uint64_t(s.virtualAddress) + (off - s.fileOffset);
            if (v <= 0xffffffffull) { va = uint32_t(v); return true; }
        }
    }
    return false;
}

static bool virtualToFile(uint32_t va, const std::vector<Segment>& segs, size_t& off) {
    for (const Segment& s : segs) {
        if (va >= s.virtualAddress && uint64_t(va) < uint64_t(s.virtualAddress) + s.fileSize) {
            const uint64_t f = uint64_t(s.fileOffset) + (va - s.virtualAddress);
            if (f <= size_t(-1)) { off = size_t(f); return true; }
        }
    }
    return false;
}

static std::vector<StringHit> fxStrings(const std::vector<uint8_t>& d,
                                        const std::vector<Segment>& segs,
                                        size_t maxStrings) {
    std::vector<StringHit> hits;
    size_t start = 0;
    std::string current;
    auto emit = [&]() {
        if (current.size() >= 4 && containsFxTerm(current) && hits.size() < maxStrings) {
            StringHit h; h.fileOffset = start; h.text = current;
            h.hasVirtualAddress = fileToVirtual(start, segs, h.virtualAddress);
            hits.push_back(std::move(h));
        }
        current.clear();
    };
    for (size_t i = 0; i <= d.size(); ++i) {
        const bool printable = i < d.size() && d[i] >= 32 && d[i] <= 126;
        if (printable) {
            if (current.empty()) start = i;
            if (current.size() < 512) current.push_back(char(d[i]));
        } else emit();
    }
    return hits;
}

static bool targetMatches(uint32_t value, const StringHit& h) {
    if (!h.hasVirtualAddress) return false;
    const uint64_t begin = h.virtualAddress;
    const uint64_t end = begin + h.text.size();
    return uint64_t(value) >= begin && uint64_t(value) <= end;
}

static uint32_t ror32(uint32_t v, unsigned s) {
    s &= 31; return s ? ((v >> s) | (v << (32 - s))) : v;
}

static uint32_t armImmediate(uint32_t word) {
    return ror32(word & 0xffu, ((word >> 8) & 15u) * 2u);
}

static uint32_t nearestArmFunction(const std::vector<uint8_t>& d,
                                   const std::vector<Segment>& segs,
                                   size_t instructionFileOffset) {
    const size_t begin = instructionFileOffset > 0x800 ? instructionFileOffset - 0x800 : 0;
    size_t p = instructionFileOffset & ~size_t(3);
    while (p >= begin + 4) {
        p -= 4;
        if (p + 4 > d.size()) continue;
        const uint32_t w = le32(&d[p]);
        if ((w & 0xFFFF0000u) == 0xE92D0000u && (w & (1u << 14))) {
            uint32_t va = 0; if (fileToVirtual(p, segs, va)) return va;
        }
        if (p == 0) break;
    }
    return 0;
}

static uint32_t nearestThumbFunction(const std::vector<uint8_t>& d,
                                     const std::vector<Segment>& segs,
                                     size_t instructionFileOffset) {
    const size_t begin = instructionFileOffset > 0x800 ? instructionFileOffset - 0x800 : 0;
    size_t p = instructionFileOffset & ~size_t(1);
    while (p >= begin + 2) {
        p -= 2;
        if (p + 2 > d.size()) continue;
        const uint16_t w = le16(&d[p]);
        if ((w & 0xFF00u) == 0xB500u) {
            uint32_t va = 0; if (fileToVirtual(p, segs, va)) return va | 1u;
        }
        if (p == 0) break;
    }
    return 0;
}

static void addRef(std::map<size_t, std::vector<RefHit>>& refs,
                   size_t stringIndex,
                   uint32_t instructionAddress,
                   uint32_t functionAddress,
                   const char* mode,
                   const char* mechanism,
                   size_t maxReferences,
                   size_t& totalReferences) {
    if (totalReferences >= maxReferences) return;
    RefHit r; r.instructionAddress = instructionAddress; r.functionAddress = functionAddress;
    r.mode = mode; r.mechanism = mechanism;
    auto& v = refs[stringIndex];
    for (const auto& x : v) if (x.instructionAddress == r.instructionAddress && x.mechanism == r.mechanism) return;
    v.push_back(std::move(r)); ++totalReferences;
}

static void scanArmReferences(const std::vector<uint8_t>& d,
                              const std::vector<Segment>& segs,
                              const std::vector<StringHit>& strings,
                              std::map<size_t, std::vector<RefHit>>& refs,
                              size_t maxReferences,
                              size_t& totalReferences) {
    for (const Segment& s : segs) {
        if ((s.flags & 1u) == 0 || s.fileSize < 4) continue;
        const size_t begin = s.fileOffset;
        const size_t end = std::min<size_t>(d.size(), uint64_t(s.fileOffset) + s.fileSize);
        for (size_t p = begin; p + 4 <= end && totalReferences < maxReferences; p += 4) {
            const uint32_t w = le32(&d[p]);
            const uint32_t va = s.virtualAddress + uint32_t(p - begin);

            // ARM LDR Rt,[pc,+/-imm12] -> literal pool -> absolute pointer to string.
            const bool singleTransfer = ((w >> 26) & 3u) == 1u;
            const bool immediateOffset = ((w >> 25) & 1u) == 0u;
            const bool preIndexed = ((w >> 24) & 1u) != 0u;
            const bool byteTransfer = ((w >> 22) & 1u) != 0u;
            const bool writeBack = ((w >> 21) & 1u) != 0u;
            const bool load = ((w >> 20) & 1u) != 0u;
            const unsigned rn = (w >> 16) & 15u;
            if (singleTransfer && immediateOffset && preIndexed && !byteTransfer && !writeBack && load && rn == 15u) {
                const uint32_t pc = va + 8u;
                const uint32_t imm = w & 0xfffu;
                const uint32_t literalVa = ((w >> 23) & 1u) ? pc + imm : pc - imm;
                size_t literalFile = 0;
                if (virtualToFile(literalVa, segs, literalFile) && literalFile + 4 <= d.size()) {
                    const uint32_t ptr = le32(&d[literalFile]);
                    for (size_t i = 0; i < strings.size(); ++i) if (targetMatches(ptr, strings[i])) {
                        addRef(refs, i, va, nearestArmFunction(d, segs, p), "ARM", "LDR literal pointer", maxReferences, totalReferences);
                    }
                }
            }

            // ADR pseudo-op is ADD/SUB Rd,pc,#rotated-immediate.
            if (((w >> 25) & 7u) == 1u && ((w >> 16) & 15u) == 15u) {
                const unsigned opcode = (w >> 21) & 15u;
                if (opcode == 4u || opcode == 2u) {
                    const uint32_t imm = armImmediate(w);
                    const uint32_t target = opcode == 4u ? va + 8u + imm : va + 8u - imm;
                    for (size_t i = 0; i < strings.size(); ++i) if (targetMatches(target, strings[i])) {
                        addRef(refs, i, va, nearestArmFunction(d, segs, p), "ARM", "ADR/ADD-SUB pc", maxReferences, totalReferences);
                    }
                }
            }

            // MOVW + nearby MOVT pair commonly materializes absolute addresses.
            if ((w & 0x0FF00000u) == 0x03000000u) {
                const unsigned rd = (w >> 12) & 15u;
                const uint32_t low = ((w >> 4) & 0xF000u) | (w & 0x0FFFu);
                for (size_t q = p + 4, steps = 0; q + 4 <= end && steps < 5; q += 4, ++steps) {
                    const uint32_t w2 = le32(&d[q]);
                    if ((w2 & 0x0FF00000u) == 0x03400000u && ((w2 >> 12) & 15u) == rd) {
                        const uint32_t high = ((w2 >> 4) & 0xF000u) | (w2 & 0x0FFFu);
                        const uint32_t target = low | (high << 16);
                        for (size_t i = 0; i < strings.size(); ++i) if (targetMatches(target, strings[i])) {
                            addRef(refs, i, va, nearestArmFunction(d, segs, p), "ARM", "MOVW/MOVT address", maxReferences, totalReferences);
                        }
                        break;
                    }
                }
            }
        }
    }
}

static void scanThumbReferences(const std::vector<uint8_t>& d,
                                const std::vector<Segment>& segs,
                                const std::vector<StringHit>& strings,
                                std::map<size_t, std::vector<RefHit>>& refs,
                                size_t maxReferences,
                                size_t& totalReferences) {
    for (const Segment& s : segs) {
        if ((s.flags & 1u) == 0 || s.fileSize < 2) continue;
        const size_t begin = s.fileOffset;
        const size_t end = std::min<size_t>(d.size(), uint64_t(s.fileOffset) + s.fileSize);
        for (size_t p = begin; p + 2 <= end && totalReferences < maxReferences; p += 2) {
            const uint16_t w = le16(&d[p]);
            const uint32_t va = s.virtualAddress + uint32_t(p - begin);
            if ((w & 0xF800u) == 0x4800u) {
                const uint32_t literalVa = ((va + 4u) & ~3u) + ((w & 0xffu) << 2u);
                size_t literalFile = 0;
                if (virtualToFile(literalVa, segs, literalFile) && literalFile + 4 <= d.size()) {
                    const uint32_t ptr = le32(&d[literalFile]);
                    for (size_t i = 0; i < strings.size(); ++i) if (targetMatches(ptr, strings[i])) {
                        addRef(refs, i, va | 1u, nearestThumbFunction(d, segs, p), "Thumb", "LDR literal pointer", maxReferences, totalReferences);
                    }
                }
            } else if ((w & 0xF800u) == 0xA000u) {
                const uint32_t target = ((va + 4u) & ~3u) + ((w & 0xffu) << 2u);
                for (size_t i = 0; i < strings.size(); ++i) if (targetMatches(target, strings[i])) {
                    addRef(refs, i, va | 1u, nearestThumbFunction(d, segs, p), "Thumb", "ADR pc-relative", maxReferences, totalReferences);
                }
            }
        }
    }
}

static bool gunzip(const uint8_t* input, size_t inputSize, std::vector<uint8_t>& output) {
    output.clear(); z_stream z{};
    if (inflateInit2(&z, 16 + MAX_WBITS) != Z_OK) return false;
    z.next_in = const_cast<Bytef*>(input);
    z.avail_in = static_cast<uInt>(std::min<size_t>(inputSize, 0xffffffffu));
    uint8_t buffer[65536]; int rc = Z_OK;
    constexpr size_t maxDecoded = 256u * 1024u * 1024u;
    while (rc == Z_OK) {
        z.next_out = buffer; z.avail_out = sizeof(buffer);
        rc = inflate(&z, Z_NO_FLUSH);
        const size_t got = sizeof(buffer) - z.avail_out;
        if (output.size() + got > maxDecoded) { inflateEnd(&z); output.clear(); return false; }
        output.insert(output.end(), buffer, buffer + got);
        if (z.avail_in == 0 && rc != Z_STREAM_END) break;
    }
    inflateEnd(&z); return rc == Z_STREAM_END;
}

static std::string coreReport(const std::vector<uint8_t>& d,
                              size_t maxStrings,
                              size_t maxReferences) {
    std::vector<Segment> segments; uint32_t entry = 0;
    const bool armElf = parseArmElf32(d, segments, entry);
    const auto strings = fxStrings(d, segments, maxStrings);

    std::ostringstream out;
    out << "KORG RE LAB — FX/DSP Hunter\n";
    if (armElf) out << "Target: ELF32 little-endian ARM  Entry: 0x" << std::hex << std::uppercase << entry << std::dec << "\n";
    else out << "Target: non-ELF/raw object; string evidence is reported, code xrefs require an ARM ELF mapping.\n";
    out << "FX/DSP strings: " << strings.size() << "\n\n";

    if (strings.empty()) {
        out << "No built-in Pa600 FX/DSP vocabulary hits were found in this object.\n";
        return out.str();
    }

    std::map<size_t, std::vector<RefHit>> refs; size_t totalReferences = 0;
    if (armElf) {
        scanArmReferences(d, segments, strings, refs, maxReferences, totalReferences);
        scanThumbReferences(d, segments, strings, refs, maxReferences, totalReferences);
    }

    for (size_t i = 0; i < strings.size(); ++i) {
        const auto& h = strings[i];
        out << "[STRING] file+0x" << std::hex << std::uppercase << h.fileOffset;
        if (h.hasVirtualAddress) out << "  VA 0x" << h.virtualAddress;
        out << std::dec << "\n  \"" << h.text << "\"\n";
        const auto it = refs.find(i);
        if (it == refs.end()) {
            out << "  xrefs: none resolved by built-in ARM/Thumb patterns\n\n";
            continue;
        }
        for (const RefHit& r : it->second) {
            out << "  xref " << r.mode << " 0x" << std::hex << std::uppercase << r.instructionAddress;
            if (r.functionAddress) out << "  function~0x" << r.functionAddress;
            out << std::dec << "  via " << r.mechanism << "\n";
        }
        out << "\n";
    }
    out << "Resolved code references: " << totalReferences << "\n";
    if (totalReferences >= maxReferences) out << "Reference limit reached.\n";
    out << "Confidence: string hits are exact byte evidence; xrefs are instruction-pattern matches and should be verified in full disassembly.\n";
    return out.str();
}

} // namespace

std::string FxHunter::report(const std::vector<uint8_t>& data,
                             size_t maxStrings,
                             size_t maxReferences) {
    if (data.empty()) return "KORG RE LAB — FX/DSP Hunter\n(empty object)\n";

    // If this is a legacy uImage, inspect the actual payload when its compression is supported.
    if (data.size() >= 64 && be32(data.data()) == 0x27051956) {
        const uint32_t payloadSize = be32(&data[12]);
        const unsigned compression = data[31];
        if (uint64_t(64) + payloadSize <= data.size()) {
            std::vector<uint8_t> payload;
            if (compression == 0) payload.assign(data.begin() + 64, data.begin() + 64 + payloadSize);
            else if (compression == 1) gunzip(&data[64], payloadSize, payload);
            if (!payload.empty()) {
                std::ostringstream out;
                out << "uImage payload inspection\n";
                out << coreReport(payload, maxStrings, maxReferences);
                return out.str();
            }
        }
    }
    return coreReport(data, maxStrings, maxReferences);
}

} // namespace krl
