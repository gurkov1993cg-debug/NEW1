#pragma once
#include "core/Model.h"
#include <string>
#include <vector>

namespace krl {

struct TargetEvidence {
    int score = 0;
    std::vector<std::string> reasons;
};

class TargetProfiler {
public:
    static TargetEvidence score(const Chunk& chunk, const std::vector<uint8_t>& data);
    static std::string report(const Analysis& analysis);
};

} // namespace krl
