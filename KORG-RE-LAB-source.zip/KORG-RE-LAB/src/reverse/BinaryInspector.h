#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace krl {
class BinaryInspector {
public:
 static std::string identify(const std::vector<uint8_t>& d);
 static std::string uImageReport(const std::vector<uint8_t>& d);
 static std::string elfReport(const std::vector<uint8_t>& d);
 static std::string elfSymbolReport(const std::vector<uint8_t>& d,size_t maxHits=200);
 static std::string dtbReport(const std::vector<uint8_t>& d,size_t maxNodes=250);
 static std::string extFilesystemReport(const std::vector<uint8_t>& d);
 static std::string firmwareFingerprintReport(const std::vector<uint8_t>& d,size_t maxHits=120);
 static std::string signaturesReport(const std::vector<uint8_t>& d,size_t maxHits=200);
 static std::string entropyReport(const std::vector<uint8_t>& d,size_t window=65536,size_t maxWindows=32);
 static std::string disassemblyPreview(const std::vector<uint8_t>& d);
};
}
