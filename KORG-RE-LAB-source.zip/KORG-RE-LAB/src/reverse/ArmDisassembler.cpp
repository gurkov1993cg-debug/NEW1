#include "ArmDisassembler.h"
#include "core/Utils.h"
#include <algorithm>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
namespace krl {
static const char* condName(unsigned c){static const char* n[]={"eq","ne","cs","cc","mi","pl","vs","vc","hi","ls","ge","lt","gt","le","","nv"};return n[c&15];}
static std::string r(unsigned n){return n==13?"sp":n==14?"lr":n==15?"pc":"r"+std::to_string(n);}
static uint32_t ror32(uint32_t v,unsigned s){s&=31;return s?((v>>s)|(v<<(32-s))):v;}
static uint32_t armImm(uint32_t w){return ror32(w&0xffu,((w>>8)&15u)*2u);}
static std::string regList(uint16_t mask,bool pcOrLr,bool useLr){std::ostringstream o;o<<"{";bool first=true;for(unsigned i=0;i<8;++i)if(mask&(1u<<i)){if(!first)o<<", ";o<<r(i);first=false;}if(pcOrLr){if(!first)o<<", ";o<<(useLr?"lr":"pc");}o<<"}";return o.str();}

std::string ArmDisassembler::disassembleArm(const std::vector<uint8_t>& d,uint32_t base,size_t maxI){
 std::ostringstream o;o<<"ARM32 preview (built-in decoder; undecoded words remain explicit)\n";
 size_t count=0;for(size_t p=0;p+4<=d.size()&&count<maxI;p+=4,++count){uint32_t w=le32(&d[p]),addr=base+(uint32_t)p;unsigned c=w>>28;std::string m;std::ostringstream t;
   if((w&0x0FFFFFF0)==0x012FFF10){t<<"bx"<<condName(c)<<" "<<r(w&15);}
   else if((w&0x0FFFFFF0)==0x012FFF30){t<<"blx"<<condName(c)<<" "<<r(w&15);}
   else if((w&0x0E000000)==0x0A000000){int32_t imm=int32_t(w&0x00FFFFFF);if(imm&0x00800000)imm|=int32_t(0xFF000000);uint32_t target=addr+8+uint32_t(imm<<2);t<<(w&0x01000000?"bl":"b")<<condName(c)<<" 0x"<<std::hex<<std::uppercase<<target;}
   else if((w&0x0E000000)==0x08000000){bool load=w&(1u<<20),pre=w&(1u<<24),up=w&(1u<<23),wb=w&(1u<<21);unsigned rn=(w>>16)&15;uint16_t list=w&0xffff;t<<(load?"ldm":"stm")<<condName(c)<<" "<<r(rn)<<(wb?"!":"")<<", {";bool first=true;for(unsigned i=0;i<16;++i)if(list&(1u<<i)){if(!first)t<<", ";t<<r(i);first=false;}t<<"}";if(pre||!up)t<<"  ; P="<<pre<<" U="<<up;}
   else if((w&0x0C000000)==0x04000000){bool load=w&(1u<<20),up=w&(1u<<23),byte=w&(1u<<22),wb=w&(1u<<21),regoff=w&(1u<<25);unsigned rn=(w>>16)&15,rd=(w>>12)&15;t<<(load?"ldr":"str")<<(byte?"b":"")<<condName(c)<<" "<<r(rd)<<", ["<<r(rn);if(regoff){unsigned rm=w&15;t<<", "<<(up?"":"-")<<r(rm);}else{uint32_t off=w&0xFFF;if(off)t<<", #"<<(up?"":"-")<<"0x"<<std::hex<<off;}t<<"]"<<(wb?"!":"");}
   else if((w&0x0C000000)==0x00000000){unsigned opcode=(w>>21)&15;bool imm=w&(1u<<25),setflags=w&(1u<<20);unsigned rn=(w>>16)&15,rd=(w>>12)&15;uint32_t op2=imm?armImm(w):0;const char* name=nullptr;switch(opcode){case 0:name="and";break;case 1:name="eor";break;case 2:name="sub";break;case 4:name="add";break;case 8:name="tst";break;case 10:name="cmp";break;case 12:name="orr";break;case 13:name="mov";break;case 14:name="bic";break;case 15:name="mvn";break;}if(name){t<<name<<condName(c)<<(setflags&&opcode!=8&&opcode!=10?"s":"")<<" ";if(opcode==8||opcode==10){t<<r(rn)<<", ";}else{t<<r(rd);if(opcode!=13&&opcode!=15)t<<", "<<r(rn);t<<", ";}if(imm)t<<"#0x"<<std::hex<<std::uppercase<<op2;else{unsigned rm=w&15;t<<r(rm);unsigned st=(w>>5)&3,sh=(w>>7)&31;if(sh)t<<", "<<(st==0?"lsl":st==1?"lsr":st==2?"asr":"ror")<<" #"<<std::dec<<sh;}}}
   m=t.str();if(m.empty()){std::ostringstream x;x<<".word 0x"<<std::hex<<std::uppercase<<std::setw(8)<<std::setfill('0')<<w;m=x.str();}
   o<<std::hex<<std::uppercase<<std::setw(8)<<std::setfill('0')<<addr<<"  "<<std::setw(8)<<w<<"  "<<m<<"\n";
 } return o.str();
}

std::string ArmDisassembler::disassembleThumb(const std::vector<uint8_t>& d,uint32_t base,size_t maxI){
 std::ostringstream o;o<<"Thumb preview (Thumb-1 plus common Thumb-2 BL)\n";size_t count=0;
 for(size_t p=0;p+2<=d.size()&&count<maxI;){uint16_t w=le16(&d[p]);uint32_t addr=base+(uint32_t)p;std::ostringstream m;size_t step=2;
   if(p+4<=d.size() && (w&0xF800)==0xF000){uint16_t w2=le16(&d[p+2]);if((w2&0xD000)==0xD000){uint32_t s=(w>>10)&1,j1=(w2>>13)&1,j2=(w2>>11)&1;uint32_t i1=(~(j1^s))&1,i2=(~(j2^s))&1;int32_t imm=int32_t((s<<24)|(i1<<23)|(i2<<22)|((w&0x03ff)<<12)|((w2&0x07ff)<<1));if(s)imm|=int32_t(0xFE000000);m<<"bl 0x"<<std::hex<<std::uppercase<<uint32_t(addr+4+imm);step=4;}}
   if(m.str().empty()&&(w&0xF800)==0xE000){int32_t imm=(w&0x7FF)<<1;if(imm&0x800)imm|=~0xFFF;m<<"b 0x"<<std::hex<<std::uppercase<<uint32_t(addr+4+imm);}
   else if(m.str().empty()&&(w&0xF000)==0xD000 && (w&0x0F00)!=0x0F00){unsigned cc=(w>>8)&15;int32_t imm=int8_t(w&0xff)*2;m<<"b"<<condName(cc)<<" 0x"<<std::hex<<std::uppercase<<uint32_t(addr+4+imm);}
   else if(m.str().empty()&&(w&0xFF87)==0x4700)m<<"bx "<<r((w>>3)&15);
   else if(m.str().empty()&&(w&0xFE00)==0xB400)m<<"push "<<regList(w&0xff,(w&0x0100)!=0,true);
   else if(m.str().empty()&&(w&0xFE00)==0xBC00)m<<"pop "<<regList(w&0xff,(w&0x0100)!=0,false);
   else if(m.str().empty()&&(w&0xF800)==0x2000)m<<"movs "<<r((w>>8)&7)<<", #0x"<<std::hex<<(w&0xFF);
   else if(m.str().empty()&&(w&0xF800)==0x2800)m<<"cmp "<<r((w>>8)&7)<<", #0x"<<std::hex<<(w&0xFF);
   else if(m.str().empty()&&(w&0xF800)==0x3000)m<<"adds "<<r((w>>8)&7)<<", #0x"<<std::hex<<(w&0xFF);
   else if(m.str().empty()&&(w&0xF800)==0x3800)m<<"subs "<<r((w>>8)&7)<<", #0x"<<std::hex<<(w&0xFF);
   else if(m.str().empty()&&(w&0xF800)==0x4800){unsigned rd=(w>>8)&7;uint32_t target=((addr+4)&~3u)+((w&0xff)<<2);m<<"ldr "<<r(rd)<<", [pc, #0x"<<std::hex<<((w&0xff)<<2)<<"]  ; 0x"<<target;}
   if(m.str().empty())m<<".hword 0x"<<std::hex<<std::uppercase<<std::setw(4)<<std::setfill('0')<<w;
   o<<std::hex<<std::uppercase<<std::setw(8)<<std::setfill('0')<<addr<<"  "<<std::setw(4)<<w;if(step==4)o<<" "<<std::setw(4)<<le16(&d[p+2]);else o<<"     ";o<<"  "<<m.str()<<"\n";p+=step;++count;
 }return o.str();
}

std::string ArmDisassembler::functionMap(const std::vector<uint8_t>& d,uint32_t base,size_t maxFunctions){
 std::set<uint32_t> funcs, calls;std::map<uint32_t,unsigned> callCount;
 for(size_t p=0;p+4<=d.size();p+=4){uint32_t w=le32(&d[p]),addr=base+(uint32_t)p;
   // Common GCC ARM prologues: stmdb sp!, {...,lr} / push alias.
   if((w&0xFFFF0000u)==0xE92D0000u && (w&(1u<<14))) funcs.insert(addr);
   if((w&0x0F000000u)==0x0B000000u){int32_t imm=int32_t(w&0x00ffffff);if(imm&0x00800000)imm|=int32_t(0xff000000);uint32_t target=addr+8+uint32_t(imm<<2);calls.insert(target);++callCount[target];}
 }
 for(uint32_t c:calls) if(c>=base && uint64_t(c-base)<d.size()) funcs.insert(c);
 // Thumb PUSH {...,lr} is a useful candidate when image is Thumb/mixed.
 for(size_t p=0;p+2<=d.size();p+=2){uint16_t w=le16(&d[p]);if((w&0xFF00u)==0xB500u) funcs.insert(base+(uint32_t)p);}
 std::ostringstream o;o<<"ARM/Thumb function candidates\n";size_t n=0;for(uint32_t f:funcs){if(n++>=maxFunctions){o<<"... candidate limit reached ...\n";break;}o<<"0x"<<std::hex<<std::uppercase<<f;auto it=callCount.find(f);if(it!=callCount.end())o<<std::dec<<"  BL refs="<<it->second;o<<"\n";}if(funcs.empty())o<<"(no common prologue/call-target candidates found)\n";return o.str();
}
}
