#pragma once
#include "core/Model.h"
#include <string>
#include <vector>

namespace krl {
class UpdParser {
public:
    static bool parse(const std::string& path, const std::vector<uint8_t>& bytes, Analysis& out, std::string& error);
};
}
