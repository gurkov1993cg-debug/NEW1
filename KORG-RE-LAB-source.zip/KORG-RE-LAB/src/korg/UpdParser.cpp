#include "UpdParser.h"
#include "PkgParser.h"
#include "core/Md5.h"
#include "core/Utils.h"
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <set>
#include <sstream>
#include <zlib.h>

namespace krl { namespace {
static uint16_t r16(const uint8_t* p,bool le){return le?le16(p):uint16_t((uint16_t(p[0])<<8)|p[1]);}
static uint32_t r32(const uint8_t* p,bool le){return le?le32(p):be32(p);}
static uint64_t r64(const uint8_t* p,bool le){if(le)return le64(p);uint64_t v=0;for(int i=0;i<8;++i)v=(v<<8)|p[i];return v;}
static bool rangeOk(uint64_t off,uint64_t len,uint64_t n){return off<=n && len<=n-off;}
static std::string offName(const char* kind,size_t idx,const char* ext){std::ostringstream o;o<<"/upd/carved/"<<kind<<"_"<<std::setw(3)<<std::setfill('0')<<idx<<ext;return o.str();}

static uint64_t elfExtent(const std::vector<uint8_t>& b,size_t off){
    if(!rangeOk(off,16,b.size())||std::memcmp(&b[off],"\x7f""ELF",4)!=0)return 0;
    const uint8_t* d=b.data()+off; bool is64=d[4]==2, le=d[5]==1; if((d[4]!=1&&d[4]!=2)||(d[5]!=1&&d[5]!=2))return 0;
    size_t minHdr=is64?64:52;if(!rangeOk(off,minHdr,b.size()))return 0;
    uint64_t end=minHdr,phoff=is64?r64(d+32,le):r32(d+28,le),shoff=is64?r64(d+40,le):r32(d+32,le);
    uint16_t phents=r16(d+(is64?54:42),le),phnum=r16(d+(is64?56:44),le),shents=r16(d+(is64?58:46),le),shnum=r16(d+(is64?60:48),le);
    if(phnum && (!phents || phoff>0x100000000ull)) return 0;
    if(shnum && (!shents || shoff>0x100000000ull)) return 0;
    if(phnum){uint64_t t=phoff+uint64_t(phents)*phnum;if(t<phoff||!rangeOk(off,t,b.size()))return 0;end=std::max(end,t);for(uint16_t i=0;i<phnum;++i){uint64_t p=phoff+uint64_t(i)*phents;if(p+phents>uint64_t(b.size()-off))return 0;const uint8_t* q=d+p;uint64_t fo=is64?r64(q+8,le):r32(q+4,le),fs=is64?r64(q+32,le):r32(q+16,le);if(fo+fs<fo||!rangeOk(off,fo+fs,b.size()))return 0;end=std::max(end,fo+fs);}}
    if(shnum){uint64_t t=shoff+uint64_t(shents)*shnum;if(t<shoff||!rangeOk(off,t,b.size()))return 0;end=std::max(end,t);for(uint16_t i=0;i<shnum;++i){uint64_t p=shoff+uint64_t(i)*shents;if(p+shents>uint64_t(b.size()-off))return 0;const uint8_t* q=d+p;uint32_t typ=r32(q+4,le);if(typ==8)continue;uint64_t so=is64?r64(q+24,le):r32(q+16,le),ss=is64?r64(q+32,le):r32(q+20,le);if(so+ss<so||!rangeOk(off,so+ss,b.size()))return 0;end=std::max(end,so+ss);}}
    return end;
}

static bool inflateGzip(const uint8_t* p,size_t n,std::vector<uint8_t>& out,size_t& used){
    out.clear();used=0;z_stream z{};if(inflateInit2(&z,16+MAX_WBITS)!=Z_OK)return false;z.next_in=(Bytef*)p;z.avail_in=(uInt)std::min<size_t>(n,0xffffffffu);const size_t cap=256u*1024u*1024u;uint8_t buf[65536];int rc=Z_OK;while(rc==Z_OK){z.next_out=buf;z.avail_out=sizeof(buf);rc=inflate(&z,Z_NO_FLUSH);size_t got=sizeof(buf)-z.avail_out;if(out.size()+got>cap){inflateEnd(&z);out.clear();return false;}out.insert(out.end(),buf,buf+got);if(z.avail_in==0&&rc!=Z_STREAM_END)break;}used=(size_t)z.total_in;inflateEnd(&z);return rc==Z_STREAM_END&&used>0;
}

static uint64_t pkgExtent(const std::vector<uint8_t>& b,size_t off){
    if(!rangeOk(off,24,b.size())) return 0;
    size_t p=off+16,count=0;
    while(p+8<=b.size()){
        uint32_t id=le32(&b[p]),sz=le32(&b[p+4]);
        if(id<1||id>19||sz>b.size()-p-8) break;
        p+=8+sz;
        size_t rel=p-off; rel=(rel+3)&~size_t(3); p=off+rel;
        ++count; if(count>100000) break;
    }
    if(count<2||p<=off+16) return 0;
    uint64_t len=p-off; if(!rangeOk(off,len,b.size())) return 0;
    std::string stored=hex(&b[off],16),calc=md5Hex(&b[off+16],(size_t)len-16);
    return stored==calc?len:0;
}

static void addSource(Analysis& a,uint32_t id,const std::string& type,const std::string& path,uint64_t off,uint64_t size,const std::string& info){Chunk c;c.id=id;c.typeName=type;c.virtualPath=path;c.headerOffset=off;c.payloadOffset=off;c.payloadSize=(uint32_t)std::min<uint64_t>(size,0xffffffffu);c.sourceBacked=true;c.sourceOffset=off;c.sourceSize=size;c.info=info;a.chunks.push_back(std::move(c));}
}

bool UpdParser::parse(const std::string& path,const std::vector<uint8_t>& b,Analysis& out,std::string& error){
    error.clear();out=Analysis{};out.sourcePath=path;out.kind=ContainerKind::KorgUpd;out.kindName="Korg Pa UPD — forensic container";out.fileSize=b.size();out.wholeFile=b;
    addSource(out,0,"UPD_CONTAINER","/upd/original/"+baseName(path),0,b.size(),"Original UPD container. Preserved byte-for-byte.\n");
    size_t nu=0,ne=0,nd=0,ng=0,np=0;std::set<std::pair<uint64_t,std::string>> seen;
    const size_t n=b.size();
    for(size_t i=0;i+4<=n;++i){
        if(b[i]==0x27&&b[i+1]==0x05&&b[i+2]==0x19&&b[i+3]==0x56&&i+64<=n){uint32_t sz=be32(&b[i+12]);uint64_t len=64ull+sz;if(sz<=512u*1024u*1024u&&rangeOk(i,len,n)&&seen.insert({i,"u"}).second){std::ostringstream q;q<<"Carved U-Boot legacy uImage at file offset 0x"<<std::hex<<std::uppercase<<i<<"; declared payload "<<std::dec<<sz<<" bytes.\n";addSource(out,0x100,"CARVED_UIMAGE",offName("uimage",nu++ ,".img"),i,len,q.str());}}
        if(b[i]==0x7f&&b[i+1]=='E'&&b[i+2]=='L'&&b[i+3]=='F'){uint64_t len=elfExtent(b,i);if(len&&len<=512ull*1024ull*1024ull&&seen.insert({i,"e"}).second){std::ostringstream q;q<<"Carved ELF at file offset 0x"<<std::hex<<std::uppercase<<i<<"; validated structural extent "<<std::dec<<len<<" bytes.\n";addSource(out,0x101,"CARVED_ELF",offName("elf",ne++ ,".elf"),i,len,q.str());}}
        if(b[i]==0xd0&&b[i+1]==0x0d&&b[i+2]==0xfe&&b[i+3]==0xed&&i+8<=n){uint32_t sz=be32(&b[i+4]);if(sz>=40&&sz<=64u*1024u*1024u&&rangeOk(i,sz,n)&&seen.insert({i,"d"}).second){std::ostringstream q;q<<"Carved Flattened Device Tree at file offset 0x"<<std::hex<<std::uppercase<<i<<"; totalsize "<<std::dec<<sz<<" bytes.\n";addSource(out,0x102,"CARVED_DTB",offName("dtb",nd++ ,".dtb"),i,sz,q.str());}}
        if(b[i]==0x1f&&b[i+1]==0x8b&&b[i+2]==0x08){std::vector<uint8_t> dec;size_t used=0;if(inflateGzip(&b[i],n-i,dec,used)&&used>=18&&seen.insert({i,"g"}).second){Chunk c;c.id=0x103;c.typeName="CARVED_GZIP_DECODED";c.virtualPath=offName("gzip",ng++ ,".decoded.bin");c.headerOffset=i;c.payloadOffset=i;c.payloadSize=(uint32_t)std::min<size_t>(used,0xffffffffu);c.sourceBacked=true;c.sourceOffset=i;c.sourceSize=used;c.decodedData=std::move(dec);c.decoded=true;std::ostringstream q;q<<"Validated gzip stream at file offset 0x"<<std::hex<<std::uppercase<<i<<"; compressed extent "<<std::dec<<used<<" bytes; decoded size "<<c.decodedData.size()<<" bytes.\n";c.info=q.str();out.chunks.push_back(std::move(c));i+=used?used-1:0;}}
        if(i+24<=n && le32(&b[i+16])==1){uint64_t len=pkgExtent(b,i);if(len&&seen.insert({i,"p"}).second){
            const size_t pkgIndex=np++;
            std::ostringstream q;q<<"Carved Korg PKG with valid package MD5 at file offset 0x"<<std::hex<<std::uppercase<<i<<"; extent "<<std::dec<<len<<" bytes.\n";
            addSource(out,0x104,"CARVED_KORG_PKG",offName("pkg",pkgIndex,".pkg"),i,len,q.str());
            // Expand a validated embedded PKG into child objects. This is not heuristic: the
            // nested package must pass the same outer MD5/chunk parser used for standalone PKG.
            std::vector<uint8_t> nestedBytes(b.begin()+i,b.begin()+i+(size_t)len);
            Analysis nested;std::string nestedError;
            if(PkgParser::parse("embedded.pkg",nestedBytes,nested,nestedError)){
                const std::string prefix="/upd/embedded_pkg_"+std::to_string(pkgIndex);
                for(size_t ci=0;ci<nested.chunks.size();++ci){
                    const Chunk& nc=nested.chunks[ci];Chunk cc=nc;
                    cc.typeName="PKG_CHILD_"+nc.typeName;
                    cc.headerOffset=i+nc.headerOffset;cc.payloadOffset=i+nc.payloadOffset;
                    cc.virtualPath=prefix+(nc.virtualPath.empty()?"/chunk_"+std::to_string(ci):nc.virtualPath);
                    if(!cc.decoded && cc.rawPayload.empty()){
                        cc.sourceBacked=true;cc.sourceOffset=i+nc.payloadOffset;cc.sourceSize=nc.payloadSize;
                    }
                    std::ostringstream ni;ni<<"Nested child of validated embedded PKG #"<<pkgIndex<<".\n"<<nc.info;cc.info=ni.str();out.chunks.push_back(std::move(cc));
                }
            }else out.warnings.push_back("Embedded PKG validated by extent/MD5 but nested parser reported: "+nestedError);
            i+=(size_t)std::min<uint64_t>(len-1,0x100000ull);
        }}
    }
    std::ostringstream w;w<<"UPD top-level layout is not guessed. Positive carving found: "<<nu<<" uImage, "<<ne<<" ELF, "<<nd<<" DTB, "<<ng<<" gzip, "<<np<<" embedded PKG object(s).";out.warnings.push_back(w.str());
    out.warnings.push_back("No guessed decryption or mutation is performed. Only objects with independently verifiable headers/extents are carved.");
    return true;
}
}
