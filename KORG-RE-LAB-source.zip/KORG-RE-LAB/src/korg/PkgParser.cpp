#include "PkgParser.h"
#include "core/Utils.h"
#include "core/Md5.h"
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <sstream>
#include <zlib.h>

namespace krl {
namespace {
struct Cursor {
    const std::vector<uint8_t>& d; size_t p=0, end=0;
    Cursor(const std::vector<uint8_t>& x,size_t a,size_t b):d(x),p(a),end(std::min(b,x.size())){}
    size_t remaining() const { return p<=end?end-p:0; }
    bool take(size_t n,const uint8_t*& q){ if(n>remaining())return false; q=d.data()+p;p+=n;return true; }
    bool u8(uint8_t&v){const uint8_t*q;if(!take(1,q))return false;v=*q;return true;}
    bool u16(uint16_t&v){const uint8_t*q;if(!take(2,q))return false;v=le16(q);return true;}
    bool u32(uint32_t&v){const uint8_t*q;if(!take(4,q))return false;v=le32(q);return true;}
    bool zstr(std::string&s){s.clear(); while(p<end){uint8_t c=d[p++];if(!c)return true;if(s.size()>65535)return false;s.push_back(char(c));}return false;}
    bool bytes(size_t n,std::vector<uint8_t>&v){const uint8_t*q;if(!take(n,q))return false;v.assign(q,q+n);return true;}
};
std::string fmt16(uint16_t v){std::ostringstream o;o<<"0x"<<std::hex<<std::uppercase<<std::setw(4)<<std::setfill('0')<<v;return o.str();}
std::string fmt32(uint32_t v){std::ostringstream o;o<<"0x"<<std::hex<<std::uppercase<<std::setw(8)<<std::setfill('0')<<v;return o.str();}
std::string digestInfo(const uint8_t* stored,const std::vector<uint8_t>& decoded){
    std::string s=hex(stored,16), c=md5Hex(decoded); return "MD5 stored: "+s+"\nMD5 decoded: "+c+"\nMD5 match: "+std::string(s==c?"YES":"NO");
}
bool inflateKorgBlocks(Cursor& c,std::vector<uint8_t>& out,std::string& error){
    out.clear();
    while(c.remaining()>=8){
        uint32_t blockType=0, sizeField=0; if(!c.u32(blockType)||!c.u32(sizeField)){error="Truncated zlib block header";return false;}
        if(blockType==0x00000101) return true;
        if(blockType!=0x00000100){ std::ostringstream o;o<<"Unexpected Korg zlib block type "<<fmt32(blockType);error=o.str();return false; }
        if(sizeField<4 || c.remaining()<4){error="Invalid Korg zlib block size";return false;}
        uint32_t compressedSize=sizeField-4;
        const uint8_t* beUnc=nullptr; if(!c.take(4,beUnc)){error="Missing uncompressed block size";return false;}
        uint32_t uncompressedSize=be32(beUnc);
        const uint8_t* comp=nullptr; if(!c.take(compressedSize,comp)){error="Truncated compressed block";return false;}
        if(uncompressedSize>64u*1024u*1024u){error="Refusing implausibly large zlib block";return false;}
        std::vector<uint8_t> tmp(uncompressedSize);
        uLongf dst=uncompressedSize; int zr=::uncompress(tmp.data(),&dst,comp,compressedSize);
        if(zr!=Z_OK){std::ostringstream o;o<<"zlib error "<<zr;error=o.str();return false;}
        tmp.resize(dst); out.insert(out.end(),tmp.begin(),tmp.end());
        size_t pad=(4-(compressedSize%4))%4; if(pad){const uint8_t*q;if(!c.take(pad,q)){error="Truncated zlib padding";return false;}}
    }
    error="Missing Korg zlib end marker"; return false;
}
}

std::string PkgParser::chunkTypeName(uint32_t id){
    switch(id){case 1:return"HEADER";case 2:return"UPDATE_KERNEL";case 3:return"UPDATE_RAMDISK";case 4:return"UPDATE_INSTALLER_APP";case 5:return"UPDATE_INSTALLER_CONFIG";case 6:return"SERVICE_KERNEL";case 7:return"SERVICE_RAMDISK";case 8:return"SERVICE_APP";case 9:return"SERVICE_APP_CONFIG";case 10:return"UPDATE_LAUNCHER_APP";case 11:return"UPDATE_LAUNCHER_CONFIG";case 12:return"MLO";case 13:return"UBOOT";case 14:return"USER_KERNEL";case 15:return"INSTALLER_SCRIPT";case 16:return"DIRECTORY";case 17:return"FILE";case 18:return"LINK";case 19:return"ROOT_FS";default:return"UNKNOWN";}
}
std::string PkgParser::systemVirtualPath(uint32_t id){
    switch(id){
        case 2:return"/update/uImage";case 3:return"/update/ramdisk.gz";case 4:return"/update/lfo-pkg-install";case 5:return"/update/lfo-pkg-install.xml";
        case 6:return"/service/uImage";case 7:return"/service/ramdisk.gz";case 8:return"/service/lfo-service";case 9:return"/service/lfo-service.xml";
        case 10:return"/service/lfo-pkg-launcher";case 11:return"/service/lfo-pkg-launcher.xml";case 12:return"/boot/MLO";case 13:return"/boot/u-boot.bin";case 14:return"/kernel/uImage";default:return{};
    }
}

bool PkgParser::looksLikePkg(const std::vector<uint8_t>& b){
    if(b.size()<32) return false;
    size_t p=16; int plausible=0;
    for(int n=0;n<4 && p+8<=b.size();++n){uint32_t id=le32(&b[p]), sz=le32(&b[p+4]);if(id<1||id>64||sz>b.size()-p-8)return false;if(id>=1&&id<=19)++plausible;p+=8+sz;p=(p+3)&~size_t(3);} return plausible>=1;
}

bool PkgParser::parse(const std::string& path,const std::vector<uint8_t>& b,Analysis& out,std::string& error){
    if(b.size()<24){error="File is too small for a Korg PKG";return false;}
    out=Analysis{};out.sourcePath=path;out.fileSize=b.size();out.kind=ContainerKind::KorgPkg;out.kindName="Korg Pa PKG";out.packageDigestPresent=true;
    out.packageDigestStored=hex(b.data(),16); out.packageDigestCalculated=md5Hex(b.data()+16,b.size()-16); out.packageDigestValid=out.packageDigestStored==out.packageDigestCalculated;
    size_t p=16; size_t index=0;
    while(p+8<=b.size()){
        size_t hOff=p; uint32_t id=le32(&b[p]);uint32_t sz=le32(&b[p+4]);
        if(id==0 && sz==0){ bool onlyZero=true; for(size_t z=p; z<b.size(); ++z) if(b[z]!=0){onlyZero=false;break;} if(onlyZero) break; }
        p+=8;
        if(sz>b.size()-p){std::ostringstream o;o<<"Chunk "<<index<<" at 0x"<<std::hex<<hOff<<" exceeds file size";out.warnings.push_back(o.str());break;}
        Chunk ch; ch.id=id;ch.payloadSize=sz;ch.headerOffset=hOff;ch.payloadOffset=p;ch.typeName=chunkTypeName(id);ch.virtualPath=systemVirtualPath(id);
        Cursor c(b,p,p+sz); std::ostringstream info; info<<"Chunk #"<<index<<"\nID: "<<id<<" ("<<ch.typeName<<")\nHeader offset: 0x"<<std::hex<<std::uppercase<<hOff<<"\nPayload offset: 0x"<<p<<"\nPayload size: "<<std::dec<<sz<<" bytes\n";
        bool parsed=true;
        if(id==1){
            if(c.remaining()<12){parsed=false;} else {
                const uint8_t*v=nullptr;c.take(4,v);std::memcpy(out.header.libVersion,v,4);c.u32(out.header.packageType);c.u16(out.header.unknownA);c.u16(out.header.unknownB);
                parsed=c.zstr(out.header.systemType)&&c.zstr(out.header.buildSystem1)&&c.zstr(out.header.buildSystem2)&&c.zstr(out.header.date)&&c.zstr(out.header.time)&&c.zstr(out.header.packageType1)&&c.zstr(out.header.packageType2);
                out.header.present=parsed;
                if(parsed){info<<"PkgLib: "<<unsigned(out.header.libVersion[0])<<'.'<<unsigned(out.header.libVersion[1])<<'.'<<unsigned(out.header.libVersion[2])<<'.'<<unsigned(out.header.libVersion[3])<<"\nPackage type: "<<out.header.packageType<<(out.header.packageType==2?" (UPDATE)":out.header.packageType==3?" (FULL)":" (UNKNOWN)")<<"\nSystem: "<<out.header.systemType<<"\nBuild: "<<out.header.buildSystem1<<" / "<<out.header.buildSystem2<<"\nDate: "<<out.header.date<<' '<<out.header.time<<"\nDescription: "<<out.header.packageType1<<" | "<<out.header.packageType2<<"\n";ch.virtualPath="/Header";}
            }
        } else if(id>=2&&id<=14){
            const uint8_t*md=nullptr;if(!c.take(16,md))parsed=false;else {ch.decodedData.assign(b.begin()+c.p,b.begin()+c.end);ch.decoded=true;info<<"Virtual path: "<<ch.virtualPath<<"\n"<<digestInfo(md,ch.decodedData)<<"\n";}
        } else if(id==15){
            const uint8_t*md=nullptr;uint16_t cond=0;std::string name;if(!c.take(16,md)||!c.u16(cond)||!c.zstr(name))parsed=false;else {ch.decodedData.assign(b.begin()+c.p,b.begin()+c.end);ch.decoded=true;ch.virtualPath="/update/"+name;info<<"Condition: "<<int16_t(cond)<<"\nName: "<<name<<"\n"<<digestInfo(md,ch.decodedData)<<"\n";}
        } else if(id==16){
            uint16_t owner=0,group=0,attr=0,cond=0;std::string vpath;if(!c.u16(owner)||!c.u16(group)||!c.u16(attr)||!c.u16(cond)||!c.zstr(vpath))parsed=false;else {ch.virtualPath=vpath;info<<"Directory: "<<vpath<<"\nOwner: "<<owner<<" Group: "<<group<<"\nAttributes: "<<fmt16(attr)<<" Condition: "<<int16_t(cond)<<"\n";}
        } else if(id==17){
            const uint8_t*md=nullptr;uint16_t owner=0,group=0,attr=0,cond=0;uint32_t dataSize=0;uint8_t compression=0;std::string name,date,time;
            if(!c.take(16,md)||!c.u16(owner)||!c.u16(group)||!c.u16(attr)||!c.u16(cond)||!c.u32(dataSize)||!c.u8(compression)||!c.zstr(name)||!c.zstr(date)||!c.zstr(time))parsed=false;
            else {ch.virtualPath=name;info<<"File: "<<name<<"\nDate: "<<date<<' '<<time<<"\nOwner: "<<owner<<" Group: "<<group<<"\nAttributes: "<<fmt16(attr)<<" Condition: "<<int16_t(cond)<<"\nDeclared data size: "<<dataSize<<"\nCompression: "<<unsigned(compression)<<(compression==0?" RAW":compression==1?" ZLIB":compression==16?" ENCRYPTED":" UNKNOWN")<<"\n";
                if(compression==0){if(dataSize>c.remaining())parsed=false;else{const uint8_t*q=nullptr;c.take(dataSize,q);ch.decodedData.assign(q,q+dataSize);ch.decoded=true;info<<digestInfo(md,ch.decodedData)<<"\n";}}
                else if(compression==1){std::string ze;if(inflateKorgBlocks(c,ch.decodedData,ze)){ch.decoded=true;info<<"Decoded size: "<<ch.decodedData.size()<<"\n"<<digestInfo(md,ch.decodedData)<<"\n";}else{parsed=false;info<<"Zlib decode error: "<<ze<<"\n";}}
                else if(compression==16){ch.encrypted=true;ch.decoded=false;ch.rawPayload.assign(b.begin()+c.p,b.begin()+c.end);info<<"Encrypted payload size: "<<ch.rawPayload.size()<<"\n";}
                else {ch.rawPayload.assign(b.begin()+c.p,b.begin()+c.end);info<<"Unknown compression payload preserved raw.\n";}
            }
        } else if(id==18){
            ch.rawPayload.assign(b.begin()+p,b.begin()+p+sz);ch.virtualPath="/link_unknown";info<<"Link chunk structure is not publicly resolved; payload preserved verbatim.\n";
        } else if(id==19){
            const uint8_t*md=nullptr;uint32_t dataSize=0;uint16_t cond=0;std::string vpath;if(!c.take(16,md)||!c.u32(dataSize)||!c.u16(cond)||!c.zstr(vpath)||dataSize>c.remaining())parsed=false;else {const uint8_t*q=nullptr;c.take(dataSize,q);ch.decodedData.assign(q,q+dataSize);ch.decoded=true;ch.virtualPath=vpath;info<<"RootFS path: "<<vpath<<"\nCondition: "<<int16_t(cond)<<"\nDeclared data size: "<<dataSize<<"\n"<<digestInfo(md,ch.decodedData)<<"\n";}
        } else {ch.rawPayload.assign(b.begin()+p,b.begin()+p+sz);info<<"Unknown chunk ID; payload preserved verbatim.\n";}
        if(!parsed){info<<"WARNING: malformed or truncated payload. Raw bytes preserved.\n";ch.rawPayload.assign(b.begin()+p,b.begin()+p+sz);out.warnings.push_back("Malformed chunk #"+std::to_string(index)+" (ID "+std::to_string(id)+")");}
        ch.info=info.str();out.chunks.push_back(std::move(ch));
        p+=sz; size_t aligned=(p+3)&~size_t(3); if(aligned>b.size()){p=b.size();break;} p=aligned; ++index;
    }
    if(out.chunks.empty()){error="No PKG chunks could be parsed";return false;}
    return true;
}
}
