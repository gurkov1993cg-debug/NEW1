#pragma once
#include "core/Model.h"
#include <string>
#include <vector>
namespace krl {
class PkgParser {
public:
    static bool looksLikePkg(const std::vector<uint8_t>& bytes);
    static bool parse(const std::string& path, const std::vector<uint8_t>& bytes, Analysis& out, std::string& error);
    static std::string chunkTypeName(uint32_t id);
    static std::string systemVirtualPath(uint32_t id);
};
}
