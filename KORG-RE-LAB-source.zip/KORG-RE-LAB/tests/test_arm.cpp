#include "reverse/ArmDisassembler.h"
#include <cassert>
#include <iostream>
#include <vector>
int main(){
    // ARM: push {r4,lr}; bl +0; mov r0,#0x100 rotated immediate; bx lr
    std::vector<uint8_t> arm={0x10,0x40,0x2d,0xe9, 0x00,0x00,0x00,0xeb, 0x01,0x0c,0xa0,0xe3, 0x1e,0xff,0x2f,0xe1};
    auto fm=krl::ArmDisassembler::functionMap(arm,0x8000,16);
    assert(fm.find("0x8000")!=std::string::npos);
    assert(fm.find("0x800C")!=std::string::npos || fm.find("0x8008")!=std::string::npos);
    auto dis=krl::ArmDisassembler::disassembleArm(arm,0x8000,16);
    assert(dis.find("bl 0x800C")!=std::string::npos);
    assert(dis.find("bx lr")!=std::string::npos);
    std::vector<uint8_t> thumb={0x10,0xb5,0x01,0x20,0x10,0xbd};
    auto td=krl::ArmDisassembler::disassembleThumb(thumb,0x1000,16);
    assert(td.find("push {r4, lr}")!=std::string::npos);
    assert(td.find("pop {r4, pc}")!=std::string::npos);
    std::cout<<"ARM/Thumb decoder tests passed\n";
}
