#include "core/FirmwareComparator.h"
#include <cassert>
#include <iostream>

static krl::Chunk chunk(const char* type,const char* path,const char* text){
    krl::Chunk c;c.typeName=type;c.virtualPath=path;c.decoded=true;c.decodedData.assign(text,text+std::char_traits<char>::length(text));c.payloadSize=(uint32_t)c.decodedData.size();return c;
}
int main(){
    krl::Analysis a,b;a.sourcePath="A.pkg";b.sourcePath="B.upd";a.kindName="Korg Pa PKG";b.kindName="Korg Pa UPD";
    a.wholeFile={'A','A','A'};b.wholeFile={'B','B','B'};
    a.chunks.push_back(chunk("UPDATE_KERNEL","/update/uImage","same kernel payload 1234567890 ABCDEFGHIJKLMNOP"));
    a.chunks.push_back(chunk("FILE","/omega_sys/fx.bin","old effect payload 1234567890"));
    b.chunks.push_back(chunk("CARVED_UIMAGE","/upd/carved/uimage_000.img","same kernel payload 1234567890 ABCDEFGHIJKLMNOP"));
    b.chunks.push_back(chunk("FILE","/omega_sys/fx.bin","new effect payload 1234567890"));
    const std::string r=krl::FirmwareComparator::compare(a,b);
    assert(r.find("Cross-container identical payloads")!=std::string::npos);
    assert(r.find("A#0")!=std::string::npos && r.find("B#0")!=std::string::npos);
    assert(r.find("CHANGED FILE|/omega_sys/fx.bin")!=std::string::npos);
    std::cout<<"Firmware comparator tests passed\n";
    return 0;
}
