#include "reverse/BinaryInspector.h"
#include "reverse/TargetProfiler.h"
#include <cassert>
#include <cstring>
#include <iostream>

static void wr16(std::vector<uint8_t>& d,size_t p,uint16_t v){d[p]=uint8_t(v);d[p+1]=uint8_t(v>>8);}
static void wr32(std::vector<uint8_t>& d,size_t p,uint32_t v){d[p]=uint8_t(v);d[p+1]=uint8_t(v>>8);d[p+2]=uint8_t(v>>16);d[p+3]=uint8_t(v>>24);}

int main(){
    std::vector<uint8_t> ext(4096,0);
    const size_t s=1024;
    wr32(ext,s+0,63744); wr32(ext,s+4,254961); wr32(ext,s+12,100000); wr32(ext,s+16,50000);
    wr32(ext,s+24,2); // 4096-byte blocks
    wr32(ext,s+32,32768); wr32(ext,s+40,7968);
    wr16(ext,s+56,0xEF53); wr16(ext,s+58,1); wr16(ext,s+60,1);
    wr32(ext,s+76,1); wr16(ext,s+88,256); wr32(ext,s+92,0x4); // journal => EXT3-family
    const char* label="rootfs"; std::memcpy(ext.data()+s+120,label,std::strlen(label));
    assert(krl::BinaryInspector::identify(ext)=="EXT2/3/4 filesystem image");
    const std::string er=krl::BinaryInspector::extFilesystemReport(ext);
    assert(er.find("EXT3-family")!=std::string::npos);
    assert(er.find("rootfs")!=std::string::npos);
    assert(er.find("4096 bytes")!=std::string::npos);

    krl::Analysis a;
    a.wholeFile=ext;
    krl::Chunk c;
    c.typeName="FILE";
    c.virtualPath="/lib/modules/2.6.32-andoria-debug/extra/kr_epf_audio_ctrl.ko";
    c.rawPayload={'E','L','F',' ','a','u','d','i','o',' ','D','S','P',' ','r','e','v','e','r','b'};
    c.payloadSize=static_cast<uint32_t>(c.rawPayload.size());
    a.chunks.push_back(c);
    krl::Chunk fs;
    fs.typeName="ROOTFS"; fs.virtualPath="/emmc/rootfs"; fs.rawPayload=ext; fs.payloadSize=static_cast<uint32_t>(ext.size());
    a.chunks.push_back(fs);
    const std::string tr=krl::TargetProfiler::report(a);
    assert(tr.find("kr_epf_audio_ctrl.ko")!=std::string::npos);
    assert(tr.find("VERY HIGH")!=std::string::npos);
    assert(tr.find("EXT filesystem image")!=std::string::npos);
    std::cout<<"target/ext tests passed\n";
    return 0;
}
