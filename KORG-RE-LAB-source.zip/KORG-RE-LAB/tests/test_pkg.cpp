#include "core/Analyzer.h"
#include "core/Md5.h"
#include "core/Utils.h"
#include <zlib.h>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>

static void u16(std::vector<uint8_t>&v,uint16_t x){v.push_back(x&255);v.push_back(x>>8);}static void u32(std::vector<uint8_t>&v,uint32_t x){for(int i=0;i<4;i++)v.push_back((x>>(8*i))&255);}static void be32v(std::vector<uint8_t>&v,uint32_t x){v.push_back(x>>24);v.push_back(x>>16);v.push_back(x>>8);v.push_back(x);}static void zs(std::vector<uint8_t>&v,const char*s){while(*s)v.push_back((uint8_t)*s++);v.push_back(0);}static std::vector<uint8_t> fromHex(const std::string&s){std::vector<uint8_t>v;for(size_t i=0;i+1<s.size();i+=2)v.push_back((uint8_t)std::stoul(s.substr(i,2),nullptr,16));return v;}
static void addChunk(std::vector<uint8_t>&pkg,uint32_t id,const std::vector<uint8_t>&p){u32(pkg,id);u32(pkg,(uint32_t)p.size());pkg.insert(pkg.end(),p.begin(),p.end());while(pkg.size()%4)pkg.push_back(0);}
int main(){
 const char* abc="abc";assert(krl::md5Hex((const uint8_t*)abc,3)=="900150983CD24FB0D6963F7D28E17F72");
 std::vector<uint8_t> pkg(16,0);
 std::vector<uint8_t> h={1,2,0,0};u32(h,3);u16(h,0);u16(h,0);zs(h,"Z105");zs(h,"build-a");zs(h,"build-b");zs(h,"2026-09-11");zs(h,"02:00");zs(h,"FULL");zs(h,"TEST");addChunk(pkg,1,h);
 std::vector<uint8_t> fileData={'h','e','l','l','o',' ','k','o','r','g','\n'};std::vector<uint8_t> f;auto fm=fromHex(krl::md5Hex(fileData));f.insert(f.end(),fm.begin(),fm.end());u16(f,0);u16(f,0);u16(f,0x1000);u16(f,0xffff);u32(f,(uint32_t)fileData.size());f.push_back(1);zs(f,"/omega_sys/test.txt");zs(f,"2026-09-11");zs(f,"02:00");
 u32(f,0x00000100);uLongf cap=compressBound(fileData.size());std::vector<uint8_t> comp(cap);int z=compress2(comp.data(),&cap,fileData.data(),fileData.size(),Z_BEST_COMPRESSION);assert(z==Z_OK);comp.resize(cap);u32(f,(uint32_t)comp.size()+4);be32v(f,(uint32_t)fileData.size());f.insert(f.end(),comp.begin(),comp.end());while(comp.size()%4){f.push_back(0);comp.push_back(0);}u32(f,0x00000101);u32(f,0);addChunk(pkg,17,f);
 auto whole=fromHex(krl::md5Hex(pkg.data()+16,pkg.size()-16));std::copy(whole.begin(),whole.end(),pkg.begin());
 std::string path="/tmp/korg_re_lab_test.pkg",err;assert(krl::writeFile(path,pkg,err));krl::Analyzer a;assert(a.open(path,err));assert(a.result().kind==krl::ContainerKind::KorgPkg);assert(a.result().packageDigestValid);assert(a.result().chunks.size()==2);assert(a.result().chunks[1].decoded);assert(a.result().chunks[1].decodedData==fileData);assert(a.result().chunks[1].virtualPath=="/omega_sys/test.txt");
 std::string root="/tmp/korg_re_lab_extract";assert(a.extractAll(root,err));auto got=krl::readFile(root+"/omega_sys/test.txt",err);assert(got==fileData);std::remove(path.c_str());std::cout<<"KORG PKG parser tests passed\n";return 0;
}
