#include "reverse/FxHunter.h"
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

static void w16(std::vector<uint8_t>& d,size_t p,uint16_t v){d[p]=uint8_t(v);d[p+1]=uint8_t(v>>8);} 
static void w32(std::vector<uint8_t>& d,size_t p,uint32_t v){d[p]=uint8_t(v);d[p+1]=uint8_t(v>>8);d[p+2]=uint8_t(v>>16);d[p+3]=uint8_t(v>>24);} 

int main(){
 std::vector<uint8_t>d(0x400,0);
 d[0]=0x7f;d[1]='E';d[2]='L';d[3]='F';d[4]=1;d[5]=1;d[6]=1;
 w16(d,16,2);w16(d,18,40);w32(d,20,1);w32(d,24,0x1000);w32(d,28,52);
 w16(d,40,52);w16(d,42,32);w16(d,44,1);
 // One executable PT_LOAD: file 0x100 -> VA 0x1000, size 0x200.
 w32(d,52,1);w32(d,56,0x100);w32(d,60,0x1000);w32(d,64,0x1000);
 w32(d,68,0x200);w32(d,72,0x200);w32(d,76,5);w32(d,80,0x1000);
 // push {lr}; ldr r0,[pc,#0x14] -> literal at VA 0x1020/file 0x120.
 w32(d,0x100,0xE92D4000);w32(d,0x104,0xE59F0014);w32(d,0x120,0x1080);
 const char*s="Stereo Chorus";std::memcpy(&d[0x180],s,std::strlen(s)+1);
 std::string r=krl::FxHunter::report(d);
 assert(r.find("Stereo Chorus")!=std::string::npos);
 assert(r.find("0x1004")!=std::string::npos);
 assert(r.find("function~0x1000")!=std::string::npos);
 assert(r.find("LDR literal pointer")!=std::string::npos);
 std::cout<<"FX hunter test passed\n";
}
