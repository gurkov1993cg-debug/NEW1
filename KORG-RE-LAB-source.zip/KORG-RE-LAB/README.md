# KORG RE LAB v4.4 — OS Inspector

Native reverse-engineering utility for Korg Pa operating-system images. All source code is C++17; the macOS UI calls the native Cocoa Objective-C runtime from C++ and does not use JUCE or Objective-C++ source files.

## Current capabilities

- Korg PKG integrity check (package MD5 over bytes after the initial 16-byte digest).
- PKG chunk map with offsets, sizes, IDs and virtual paths.
- Parses header, system-file, installer-script, directory, file, link/unknown and rootfs records.
- RAW and Korg block-ZLIB file extraction.
- Encrypted payloads are explicitly marked and preserved verbatim; unknown encryption is never presented as decrypted.
- Validated UPD forensic carving for uImage, ELF, DTB, gzip and embedded Korg PKG objects.
- A validated embedded PKG is expanded into `PKG_CHILD_*` objects so its kernel, ramdisk, installer, directories/files and rootfs can be inspected directly from the UPD view.
- Source-backed carving/extraction so large objects can be preserved without duplicating the entire firmware in memory.
- U-Boot uImage header CRC + data CRC validation and gzip payload decoding for ARM preview.
- ELF metadata, executable PT_LOAD selection for disassembly and audio/FX-oriented SYMTAB/DYNSYM scan.
- DTB parser with hardware-focused node reporting for DSP, remoteproc, mailbox, McASP/I2S, codec, DMA, I2C/SPI and related devices.
- Firmware fingerprint search for Linux/KORG/workhorse/arvon/Andoria/ALSA/DSP/effect-related strings, including Pa600 `kr_epf_*` audio/platform modules observed in a real update log.
- Shannon entropy map for UPD containers.
- ASCII strings, hex dump and ARM32/Thumb disassembly preview.
- ARM/Thumb function-candidate map from common GCC prologues plus ARM `BL` call targets and reference counts.
- Dedicated FX/DSP Hunter using Pa600 effect vocabulary, ELF file-offset→virtual-address mapping, ARM/Thumb literal/ADR/MOVW+MOVT xrefs, and nearest-function correlation.
- Pa600 Target Profiler triages every parsed object using concrete audio/platform evidence such as `kr_epf_audio_ctrl.ko`, Andoria, omega_sys/rootfs paths, ARM ELF metadata and FX/DSP code xrefs.
- EXT2/3/4 superblock inspection reports filesystem family, label, block size, inode/block counts and journal/extents features; this is useful for Pa600 rootfs images.
- Improved ARM immediate decoding plus common ARM load/store, block-transfer, branch and data-processing instructions; Thumb PUSH/POP, conditional branch, literal LDR and Thumb-2 BL decoding.
- Extract selected object or the complete parsed tree.
- Firmware comparator for version-to-version and PKG-to-UPD analysis, including cross-container identical-payload matching by MD5.
- Native macOS `Compare OS…` command plus CLI comparison mode.

## CLI

```bash
korg-re-lab-cli firmware.pkg
korg-re-lab-cli firmware.upd --extract output_directory
korg-re-lab-cli extracted_audio_binary.elf --fx 0
korg-re-lab-cli firmware.pkg --targets
korg-re-lab-cli firmware_A.pkg --compare firmware_B.upd
```

## macOS target

The supplied GitHub Actions workflow builds an Intel `x86_64` application with deployment target macOS 10.13, suitable for an Intel iMac 2011 running High Sierra when its OS/security configuration allows unsigned/ad-hoc signed applications.

## Build and tests

```bash
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

Tests cover PKG parsing/decompression/integrity, UPD validated carving/uImage CRC/gzip/embedded-PKG expansion/extraction, firmware comparison, ARM/Thumb decoding/function discovery, FX/DSP string-to-code xrefs, EXT filesystem parsing and Pa600 target triage. The current source passes `-Wall -Wextra -Wpedantic -Werror` and AddressSanitizer/UndefinedBehaviorSanitizer test runs on the available Linux build host.

## Research notes

- `docs/KORG_PKG_FORMAT.md` — implemented PKG container details.
- `docs/KORG_UPD_FORENSICS.md` — conservative UPD strategy and validation rules.
- `docs/PA600_TARGET_MAP.md` — current DSP/audio hardware targets and what remains to prove.
- `docs/FX_DSP_HUNTER.md` — evidence rules and ARM/Thumb xref strategy for locating effect code.
- `docs/PA600_TARGET_MAP.md` — now also records Andoria/rootfs/module evidence from a real Pa600QT update log.

## Safety

Inspection, comparison and extraction are read-only with respect to the input firmware. No flash/write-to-keyboard functionality is included.
